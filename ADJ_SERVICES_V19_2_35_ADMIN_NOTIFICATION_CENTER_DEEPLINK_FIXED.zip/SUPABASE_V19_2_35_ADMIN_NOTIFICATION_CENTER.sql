-- ADJ SERVICES V19.2.35
-- Unified Admin Notification Center RPC
-- Audiences: all_customers, customer, all_technicians, technician, admin_staff
-- Every target becomes a notifications row; the existing AFTER INSERT trigger on
-- public.notifications queues send-push, so database save + push stay together.

CREATE OR REPLACE FUNCTION public.admin_send_notification(
  p_audience text,
  p_recipient_id uuid DEFAULT NULL,
  p_title text DEFAULT NULL,
  p_message text DEFAULT NULL,
  p_notification_type text DEFAULT 'general',
  p_target_page text DEFAULT 'notifications',
  p_target_params jsonb DEFAULT '{}'::jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me_role text;
  sent_count integer := 0;
  r record;
  t text := lower(coalesce(p_notification_type,'general'));
  target text := lower(coalesce(p_target_page,'notifications'));
BEGIN
  SELECT lower(coalesce(role,'')) INTO me_role FROM public.profiles WHERE id = auth.uid();
  IF me_role NOT IN ('admin','staff') THEN
    RAISE EXCEPTION 'Only Admin/Staff can send notifications';
  END IF;
  IF nullif(trim(p_title),'') IS NULL OR nullif(trim(p_message),'') IS NULL THEN
    RAISE EXCEPTION 'Title and message are required';
  END IF;
  IF p_audience NOT IN ('all_customers','customer','all_technicians','technician','admin_staff') THEN
    RAISE EXCEPTION 'Invalid notification audience';
  END IF;

  IF p_audience='customer' THEN
    IF p_recipient_id IS NULL THEN RAISE EXCEPTION 'Customer is required'; END IF;
    FOR r IN SELECT id FROM public.profiles WHERE id=p_recipient_id AND lower(coalesce(role,''))='customer' LOOP
      INSERT INTO public.notifications(user_id,title,message,type,notification_type,is_read,created_by,target_page,target_params,customer_id)
      VALUES(r.id,trim(p_title),trim(p_message),t,t,false,auth.uid(),target,coalesce(p_target_params,'{}'::jsonb),r.id);
      sent_count:=sent_count+1;
    END LOOP;
  ELSIF p_audience='technician' THEN
    IF p_recipient_id IS NULL THEN RAISE EXCEPTION 'Technician is required'; END IF;
    FOR r IN SELECT id FROM public.profiles WHERE id=p_recipient_id AND lower(coalesce(role,''))='technician' LOOP
      INSERT INTO public.notifications(user_id,title,message,type,notification_type,is_read,created_by,target_page,target_params,technician_id)
      VALUES(r.id,trim(p_title),trim(p_message),t,t,false,auth.uid(),target,coalesce(p_target_params,'{}'::jsonb),r.id);
      sent_count:=sent_count+1;
    END LOOP;
  ELSIF p_audience='all_customers' THEN
    FOR r IN SELECT id FROM public.profiles WHERE lower(coalesce(role,''))='customer' LOOP
      INSERT INTO public.notifications(user_id,title,message,type,notification_type,is_read,created_by,target_page,target_params,customer_id)
      VALUES(r.id,trim(p_title),trim(p_message),t,t,false,auth.uid(),target,coalesce(p_target_params,'{}'::jsonb),r.id);
      sent_count:=sent_count+1;
    END LOOP;
  ELSIF p_audience='all_technicians' THEN
    FOR r IN SELECT id FROM public.profiles WHERE lower(coalesce(role,''))='technician' LOOP
      INSERT INTO public.notifications(user_id,title,message,type,notification_type,is_read,created_by,target_page,target_params,technician_id)
      VALUES(r.id,trim(p_title),trim(p_message),t,t,false,auth.uid(),target,coalesce(p_target_params,'{}'::jsonb),r.id);
      sent_count:=sent_count+1;
    END LOOP;
  ELSE
    FOR r IN SELECT id FROM public.profiles WHERE lower(coalesce(role,'')) IN ('admin','staff') LOOP
      INSERT INTO public.notifications(user_id,title,message,type,notification_type,is_read,created_by,target_page,target_params)
      VALUES(r.id,trim(p_title),trim(p_message),t,t,false,auth.uid(),target,coalesce(p_target_params,'{}'::jsonb));
      sent_count:=sent_count+1;
    END LOOP;
  END IF;

  RETURN jsonb_build_object('success',true,'sent_count',sent_count,'audience',p_audience,'target_page',target,'notification_type',t);
END;
$$;

REVOKE ALL ON FUNCTION public.admin_send_notification(text,uuid,text,text,text,text,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_send_notification(text,uuid,text,text,text,text,jsonb) TO authenticated;
