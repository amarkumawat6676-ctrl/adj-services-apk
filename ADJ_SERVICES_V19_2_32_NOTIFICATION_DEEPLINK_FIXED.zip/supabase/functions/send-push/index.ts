// ADJ SERVICES — unified push sender
// Deploy as Supabase Edge Function: send-push
// Required secrets:
//   FIREBASE_SERVICE_ACCOUNT_JSON
// Existing Web Push secrets:
//   VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT
// Supabase runtime secrets:
//   SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (or SUPABASE_SECRET_KEY)

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SignJWT, importPKCS8 } from "npm:jose@5.10.0";
import webpush from "npm:web-push@3.6.7";

type NotificationRecord = {
  id?: string;
  user_id?: string;
  title?: string;
  message?: string;
  type?: string;
  booking_id?: string | null;
  url?: string | null;
  target_page?: string | null;
  target_params?: Record<string, unknown> | null;
  notification_type?: string | null;
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRole =
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ??
  Deno.env.get("SUPABASE_SECRET_KEY")!;

const supabase = createClient(supabaseUrl, serviceRole);

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", "access-control-allow-origin": "*" },
  });

async function firebaseAccessToken(sa: any) {
  const now = Math.floor(Date.now() / 1000);
  const privateKey = String(sa.private_key).replace(/\\n/g, "\n");
  const key = await importPKCS8(privateKey, "RS256");
  const assertion = await new SignJWT({
    scope: "https://www.googleapis.com/auth/firebase.messaging",
  })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(sa.client_email)
    .setAudience("https://oauth2.googleapis.com/token")
    .setIssuedAt(now)
    .setExpirationTime(now + 3600)
    .sign(key);

  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body:
      "grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=" +
      encodeURIComponent(assertion),
  });
  const data = await r.json();
  if (!r.ok || !data.access_token) {
    throw new Error(`Firebase OAuth failed: ${r.status} ${JSON.stringify(data)}`);
  }
  return data.access_token as string;
}

async function sendFcm(record: NotificationRecord) {
  const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON");
  if (!saRaw) return { sent: 0, failed: 0, skipped: true, reason: "FIREBASE_SERVICE_ACCOUNT_JSON missing" };

  const sa = JSON.parse(saRaw);
  const { data: rows, error } = await supabase
    .from("fcm_tokens")
    .select("id,token")
    .eq("user_id", record.user_id!);

  if (error) throw error;
  if (!rows?.length) return { sent: 0, failed: 0, skipped: true, reason: "no FCM token" };

  const access = await firebaseAccessToken(sa);
  const endpoint = `https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`;
  let sent = 0, failed = 0;

  for (const row of rows) {
      const message = {
      message: {
        token: row.token,
        // DATA-ONLY FCM: ADJFirebaseMessagingService creates the Android
        // notification and PendingIntent in every app state. This prevents
        // Android's system tray from dropping our deep-link URL on taps.
        data: {
          title: String(record.title || "ADJ SERVICES"),
          body: String(record.message || "You have a new update."),
          url: String(record.url || "https://adjservices.pages.dev/"),
          type: String(record.type || "general"),
          booking_id: String(record.booking_id || ""),
        },
        android: {
          priority: "HIGH",
        },
      },
    };

    const r = await fetch(endpoint, {
      method: "POST",
      headers: {
        authorization: `Bearer ${access}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(message),
    });

    if (r.ok) {
      sent++;
    } else {
      failed++;
      const body = await r.text();
      // FCM HTTP v1 uses UNREGISTERED for dead/expired registration tokens.
      if (r.status === 404 || body.includes("UNREGISTERED")) {
        await supabase.from("fcm_tokens").delete().eq("id", row.id);
      }
      console.error("FCM send failed", r.status, body);
    }
  }
  return { sent, failed, skipped: false };
}

async function sendWebPush(record: NotificationRecord) {
  const pub = Deno.env.get("VAPID_PUBLIC_KEY");
  const priv = Deno.env.get("VAPID_PRIVATE_KEY");
  const subject = Deno.env.get("VAPID_SUBJECT") || "mailto:admin@adjservices.in";
  if (!pub || !priv) return { sent: 0, failed: 0, skipped: true, reason: "VAPID secrets missing" };

  webpush.setVapidDetails(subject, pub, priv);

  const { data: subs, error } = await supabase
    .from("push_subscriptions")
    .select("id,endpoint,p256dh,auth")
    .eq("user_id", record.user_id!);

  if (error) throw error;
  if (!subs?.length) return { sent: 0, failed: 0, skipped: true, reason: "no Web Push subscription" };

  const payload = JSON.stringify({
    title: record.title || "ADJ SERVICES",
    body: record.message || "You have a new update.",
    url: record.url || "/",
    type: record.type || "general",
    booking_id: record.booking_id || null,
  });

  let sent = 0, failed = 0;
  for (const sub of subs) {
    try {
      await webpush.sendNotification(
        { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
        payload
      );
      sent++;
    } catch (e) {
      failed++;
      const status = Number((e as any)?.statusCode || 0);
      if (status === 404 || status === 410) {
        await supabase.from("push_subscriptions").delete().eq("id", sub.id);
      }
      console.error("Web Push send failed", status, e);
    }
  }
  return { sent, failed, skipped: false };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204 });

  try {
    const payload = await req.json();
    const record: NotificationRecord | undefined = payload?.record;
    if (!record?.user_id) return json({ success: false, message: "Notification user_id is missing" }, 400);

    // Resolve recipient role and build one canonical deep-link for both
    // Android FCM and browser Web Push. Existing DB rows do not need a new
    // column: booking_id + notification type are enough to route correctly.
    if (!record.url) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", record.user_id)
        .maybeSingle();
      const role = String(profile?.role || "customer").toLowerCase();
      const portal = role === "admin" || role === "staff" ? "admin.html"
        : role === "technician" ? "technician.html"
        : "customer.html";
      const type = String(record.notification_type || record.type || "general").toLowerCase();
      const params = new URLSearchParams();
      params.set("notification", "1");
      params.set("type", type);
      if (record.booking_id) params.set("booking_id", String(record.booking_id));
      if (type === "chat") params.set("chat", "1");
      record.url = `https://adjservices.pages.dev/${portal}?${params.toString()}`;
    }

    const [fcm, web] = await Promise.all([sendFcm(record), sendWebPush(record)]);

    return json({
      success: true,
      user_id: record.user_id,
      fcm,
      web_push: web,
      sent: (fcm.sent || 0) + (web.sent || 0),
    });
  } catch (e) {
    console.error(e);
    return json({ success: false, error: String((e as any)?.message || e) }, 500);
  }
});
