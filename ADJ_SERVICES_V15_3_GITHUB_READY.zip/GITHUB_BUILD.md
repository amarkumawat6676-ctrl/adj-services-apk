# ADJ SERVICES V15.3 — GitHub Ready

This repository is prepared for GitHub Actions Android APK build.

## Build
1. Create a GitHub repository.
2. Upload/push the contents of this folder to the repository (do not upload the outer ZIP itself as a single file).
3. Open **Actions**.
4. Select **Build ADJ SERVICES APK**.
5. Run **Build workflow**.
6. Open the completed workflow run and download the artifact:
   `ADJ-SERVICES-V15.3-release`

The Firebase `google-services.json` is already placed in the Android app module.

No Firebase service-account private key is included in this repository.
That server credential belongs only in Supabase Edge Function Secrets, as previously configured.
