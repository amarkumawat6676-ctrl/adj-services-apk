# ADJ SERVICES V14.2 — GitHub Build Fix

This project is intended to be uploaded as the repository source files, not as a ZIP file.

The GitHub Actions workflow now builds the Android project directly from the repository root.
It does NOT look for `ADJ_SERVICES_V14_SUPER_FAST.zip` or any other ZIP archive.

V14.2 includes the contextual WebView permission handling and the website cache-bypass URL used by the Android WebView.

Important: replace the existing `.github/workflows/build-apk.yml` with the included workflow.
