-- ADJ SERVICES V5 DATABASE FIX
-- Run this whole file once in Supabase SQL Editor.
-- Fixes: booking relationships, reviews/job sheets loading, notifications,
-- realtime notification popup, technician assignment/contact, reminders.

begin;

-- ============================================================
-- 1. POSTGREST RELATIONSHIPS: JOB SHEETS + REVIEWS -> BOOKINGS
-- ============================================================

-- Create the booking relationship if it is missing.
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'technician_job_sheets_booking_id_fkey'
      and conrelid = 'public.technician_job_sheets'::regclass
  ) then
    alter table public.technician_job_sheets
      add constraint technician_job_sheets_booking_id_fkey
      foreign key (booking_id) references public.bookings(id) not valid;
  end if;
exception when duplicate_object then null;
end $$;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'reviews_booking_id_fkey'
      and conrelid = 'public.reviews'::regclass
  ) then
    alter table public.reviews
      add constraint reviews_booking_id_fkey
      foreign key (booking_id) references public.bookings(id) not valid;
  end if;
exception when duplicate_object then null;
end $$;

-- One job sheet and one review per booking, matching the app upsert logic.
do $$
begin
  delete from public.technician_job_sheets a
  using public.technician_job_sheets b
  where a.booking_id = b.booking_id
    and a.created_at < b.created_at;
exception when others then null;
end $$;
create unique index if not exists technician_job_sheets_booking_id_key
on public.technician_job_sheets(booking_id);

create unique index if not exists reviews_booking_id_key
on public.reviews(booking_id);

-- ============================================================
-- 2. NOTIFICATIONS: REMOVE OLD CHECK + ENABLE LIVE REALTIME
-- ============================================================

do $$
begin
  if exists (
    select 1 from pg_constraint
    where conname = 'notifications_type_check'
      and conrelid = 'public.notifications'::regclass
  ) then
    alter table public.notifications drop constraint notifications_type_check;
  end if;
exception when undefined_table then null;
end $$;

alter table public.notifications
  alter column type set default 'general';

-- Realtime publication. Safe if notifications is already included.
do $$
begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null;
         when undefined_object then null;
end $$;

alter table public.notifications enable row level security;
grant select, insert, update on public.notifications to authenticated;

drop policy if exists "ADJ notifications read" on public.notifications;
drop policy if exists "ADJ notifications insert" on public.notifications;
drop policy if exists "ADJ notifications update" on public.notifications;

create policy "ADJ notifications read"
on public.notifications for select to authenticated
using (user_id = auth.uid() or get_my_role() = 'admin');

create policy "ADJ notifications insert"
on public.notifications for insert to authenticated
with check (user_id = auth.uid() or get_my_role() = 'admin');

create policy "ADJ notifications update"
on public.notifications for update to authenticated
using (user_id = auth.uid() or get_my_role() = 'admin')
with check (user_id = auth.uid() or get_my_role() = 'admin');

-- ============================================================
-- 3. TECHNICIAN PROFILE / ASSIGNMENT ACCESS
-- ============================================================

alter table public.profiles enable row level security;
grant select on public.profiles to authenticated;

drop policy if exists "ADJ technician profiles public read" on public.profiles;
create policy "ADJ technician profiles public read"
on public.profiles for select to authenticated
using (
  id = auth.uid()
  or role = 'technician'
  or get_my_role() = 'admin'
);

alter table public.technicians enable row level security;
grant select, update on public.technicians to authenticated;

drop policy if exists "ADJ technicians read all" on public.technicians;
drop policy if exists "ADJ technicians self/admin update" on public.technicians;
create policy "ADJ technicians read all"
on public.technicians for select to authenticated using (true);
create policy "ADJ technicians self/admin update"
on public.technicians for update to authenticated
using (id = auth.uid() or get_my_role() = 'admin')
with check (id = auth.uid() or get_my_role() = 'admin');

alter table public.bookings add column if not exists technician_phone text;
alter table public.bookings add column if not exists technician_photo text;

-- Secure admin assignment: saves technician name/phone/photo on the booking
-- and creates a customer notification in one transaction.
create or replace function public.admin_assign_booking(
  p_booking_id uuid,
  p_technician_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r_role text;
  t_name text;
  t_phone text;
  t_photo text;
  c_id uuid;
  b_code text;
begin
  select lower(coalesce(role,'')) into r_role
  from public.profiles where id = auth.uid();

  if r_role <> 'admin' then
    raise exception 'Only an admin can assign technicians';
  end if;

  select p.full_name, p.phone, t.photo_url, b.customer_id, b.booking_code
  into t_name, t_phone, t_photo, c_id, b_code
  from public.technicians t
  join public.profiles p on p.id = t.id
  join public.bookings b on b.id = p_booking_id
  where t.id = p_technician_id;

  if t_name is null then
    raise exception 'Technician not found';
  end if;

  update public.bookings
  set technician_id = p_technician_id,
      technician_phone = coalesce(t_phone,''),
      technician_photo = coalesce(t_photo,''),
      technician_notes = 'Assigned Technician: ' || t_name,
      status = 'Assigned',
      assigned_at = now(),
      updated_at = now()
  where id = p_booking_id;

  if c_id is not null then
    insert into public.notifications(user_id,title,message,type,booking_id,is_read)
    values(c_id,'Technician Assigned',
      'Technician ' || t_name || ' has been assigned to your booking.',
      'technician_assigned',p_booking_id,false);
  end if;

  return jsonb_build_object(
    'success',true,
    'technician_id',p_technician_id,
    'technician_name',t_name,
    'technician_phone',coalesce(t_phone,''),
    'technician_photo',coalesce(t_photo,''),
    'booking_code',b_code
  );
end;
$$;

revoke all on function public.admin_assign_booking(uuid,uuid) from public;
grant execute on function public.admin_assign_booking(uuid,uuid) to authenticated;

-- ============================================================
-- 4. JOB SHEETS: ADMIN + TECHNICIAN + CUSTOMER READ ACCESS
-- ============================================================

alter table public.technician_job_sheets enable row level security;
grant select, insert, update on public.technician_job_sheets to authenticated;

drop policy if exists "ADJ technician job sheet select" on public.technician_job_sheets;
drop policy if exists "ADJ technician job sheet insert" on public.technician_job_sheets;
drop policy if exists "ADJ technician job sheet update" on public.technician_job_sheets;

create policy "ADJ technician job sheet select"
on public.technician_job_sheets for select to authenticated
using (
  technician_id = auth.uid()
  or get_my_role() = 'admin'
  or exists(select 1 from public.bookings b where b.id = booking_id and b.customer_id = auth.uid())
);

create policy "ADJ technician job sheet insert"
on public.technician_job_sheets for insert to authenticated
with check (technician_id = auth.uid() or get_my_role() = 'admin');

create policy "ADJ technician job sheet update"
on public.technician_job_sheets for update to authenticated
using (technician_id = auth.uid() or get_my_role() = 'admin')
with check (technician_id = auth.uid() or get_my_role() = 'admin');

-- ============================================================
-- 5. REVIEWS ACCESS
-- ============================================================

alter table public.reviews enable row level security;
grant select, insert, update on public.reviews to authenticated;

drop policy if exists "ADJ reviews read" on public.reviews;
drop policy if exists "ADJ reviews insert" on public.reviews;
drop policy if exists "ADJ reviews update" on public.reviews;

create policy "ADJ reviews read"
on public.reviews for select to authenticated
using (customer_id = auth.uid() or get_my_role() = 'admin');

create policy "ADJ reviews insert"
on public.reviews for insert to authenticated
with check (customer_id = auth.uid() or get_my_role() = 'admin');

create policy "ADJ reviews update"
on public.reviews for update to authenticated
using (customer_id = auth.uid() or get_my_role() = 'admin')
with check (customer_id = auth.uid() or get_my_role() = 'admin');

-- ============================================================
-- 6. SERVICE REMINDERS ACCESS
-- ============================================================

alter table public.service_reminders enable row level security;
grant select, insert, update on public.service_reminders to authenticated;

drop policy if exists "ADJ reminders read" on public.service_reminders;
drop policy if exists "ADJ reminders insert" on public.service_reminders;
drop policy if exists "ADJ reminders update" on public.service_reminders;

create policy "ADJ reminders read"
on public.service_reminders for select to authenticated
using (
  customer_id = auth.uid()
  or get_my_role() = 'admin'
  or exists(select 1 from public.bookings b where b.id = booking_id and b.technician_id = auth.uid())
);

create policy "ADJ reminders insert"
on public.service_reminders for insert to authenticated
with check (
  get_my_role() = 'admin'
  or exists(select 1 from public.bookings b where b.id = booking_id and b.technician_id = auth.uid())
);

create policy "ADJ reminders update"
on public.service_reminders for update to authenticated
using (
  get_my_role() = 'admin'
  or exists(select 1 from public.bookings b where b.id = booking_id and b.technician_id = auth.uid())
)
with check (
  get_my_role() = 'admin'
  or exists(select 1 from public.bookings b where b.id = booking_id and b.technician_id = auth.uid())
);

notify pgrst, 'reload schema';
commit;
