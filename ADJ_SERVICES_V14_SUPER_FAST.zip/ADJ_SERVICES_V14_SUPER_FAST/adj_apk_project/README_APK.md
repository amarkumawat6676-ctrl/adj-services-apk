# ADJ SERVICES — V10 APK Ready Project

This package wraps the existing ADJ SERVICES V10 frontend inside a native Android WebView.

## Backend safety
- The Supabase URL/key and frontend logic are carried over unchanged from the supplied V10 ZIP.
- No SQL migration is required for this Android wrapper.
- Do NOT run the included SQL again just for building the APK.

## Build APK
1. Install Android Studio on a PC/laptop.
2. Open this folder (`ADJ_SERVICES_APK_READY`) in Android Studio.
3. Let Gradle sync/download the Android Gradle Plugin if prompted.
4. Select **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be generated under `app/build/outputs/apk/debug/`.
6. For a shareable release APK, use **Build > Generate Signed App Bundle / APK** and create a keystore.

## Important
The web app uses Supabase over HTTPS and external WhatsApp/Call/Maps links. Internet permission is enabled. The current in-app notification system remains the same; this wrapper does not replace it with Firebase push notifications.

## Package
Application ID: `in.adjservices.app`
Version: `10.0` / versionCode `10`

## V11 UI Fix
Fixed Android system-bar/edge-to-edge handling so the website header and
top content are positioned below the phone status bar. Backend/Supabase
configuration is unchanged.
