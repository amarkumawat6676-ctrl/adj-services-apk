const CACHE_NAME = 'adj-services-pwa-v9-design-only-20260904-01';
const CORE = ['./','./index.html','./manifest.json','./icons/adj-logo.png','./icons/icon-64.png','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(CORE).catch(()=>{})));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req=event.request;
  if(req.method!=='GET') return;
  event.respondWith(fetch(req).then(res=>{const copy=res.clone(); caches.open(CACHE_NAME).then(c=>c.put(req,copy)).catch(()=>{}); return res;}).catch(()=>caches.match(req).then(r=>r||caches.match('./index.html'))));
});
