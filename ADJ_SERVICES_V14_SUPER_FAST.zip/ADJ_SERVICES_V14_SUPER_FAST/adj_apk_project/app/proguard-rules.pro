# ADJ SERVICES - no custom ProGuard rules required.
