ADJ SERVICES V14.5

Fixes:
- Customer login triggers automatic latest-version check.
- Existing logged-in customer sessions also check after app reopen.
- Customer Profile keeps Check App Version.
- Update download uses native Android DownloadManager through ADJNative.
- APK version is 14.5 (versionCode 18).
- Website update source remains https://adjservices.pages.dev/app-version.json.
