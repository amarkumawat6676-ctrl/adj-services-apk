# ADJ SERVICES — V14.3 APK Project

This project keeps the existing Customer + Admin + Technician structure and adds:

- Contextual Android permissions only when needed.
- WebView auto-refresh so the hosted ADJ SERVICES website loads the newest version.
- Customer Profile → **Check App Version**.
- Automatic update popup after customer login when a newer version is available.
- Native Android APK download through DownloadManager.
- Runtime version checking from the ADJ SERVICES website (no GitHub Release/API dependency).

## Website update files

The APK checks:

- `https://adjservices.pages.dev/app-version.json`
- `https://adjservices.pages.dev/downloads/ADJ-SERVICES.apk`

Keep `app-version.json` on the website root and keep the downloadable APK at `downloads/ADJ-SERVICES.apk`.
When releasing a new APK, update `latestVersion` and replace the APK at that same path. Keep the filename `ADJ-SERVICES.apk` stable.

Example manifest:

```json
{
  "latestVersion": "14.3",
  "tag": "v14.3",
  "downloadUrl": "https://adjservices.pages.dev/downloads/ADJ-SERVICES.apk",
  "forceUpdate": false,
  "message": "A new ADJ SERVICES app update is available."
}
```

## Build workflow

1. Upload `ADJ_SERVICES_V14_3_ONE_UPLOAD.zip` and `.github/workflows/build-apk.yml` to the APK repository.
2. Run the GitHub Action and wait for the green build.
3. The generated artifact contains `ADJ-SERVICES.apk`.
4. Put that APK on the website at `downloads/ADJ-SERVICES.apk` and update `app-version.json` to the new version.

GitHub can still be used only to build the APK; customers do not need to use GitHub for updates.
