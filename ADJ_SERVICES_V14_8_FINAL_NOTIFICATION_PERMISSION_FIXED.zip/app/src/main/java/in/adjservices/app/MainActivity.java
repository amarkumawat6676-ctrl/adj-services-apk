package in.adjservices.app;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.ActivityNotFoundException;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_NOTIFICATION = 100;
    private static final int REQ_LOCATION = 101;
    private static final int REQ_MEDIA = 102;
    private static final int REQ_CAMERA_AUDIO = 103;
    private static final String PREF_NOTIFICATION_REQUESTED = "notification_requested";
    private static final String UPDATE_MANIFEST_URL = "https://adjservices.pages.dev/app-version.json";
    private static final String PREFS = "adj_update";
    private static final String PREF_DOWNLOAD_ID = "download_id";

    private WebView webView;
    private FrameLayout root;
    private PermissionRequest pendingWebPermission;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private ValueCallback<Uri[]> filePathCallback;
    private WebChromeClient.FileChooserParams pendingFileChooserParams;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(11, 59, 130));
        window.setNavigationBarColor(Color.rgb(246, 248, 252));
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);
        setupWebView();
    }

    @Override protected void onResume() {
        super.onResume();
        checkCompletedUpdateDownload();
    }

    private void setupWebView() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setFitsSystemWindows(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars() | WindowInsets.Type.displayCutout());
                top = bars.top; bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop(); bottom = insets.getSystemWindowInsetBottom();
            }
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) webView.getLayoutParams();
            params.topMargin = top; params.bottomMargin = bottom;
            webView.setLayoutParams(params);
            return insets;
        });
        root.post(() -> root.requestApplyInsets());

        WebSettings s = webView.getSettings();
        s.setUserAgentString(s.getUserAgentString() + " ADJServicesAPK/14.8");
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new ADJNativeBridge(), "ADJNative");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                // Only request Android permissions when the webpage explicitly asks for them.
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }

            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                // Location permission is requested only when the webpage invokes geolocation.
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }

            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                pendingFileChooserParams = params;
                // Android's system picker is used for files/photos. No storage permission is requested here.
                try {
                    startActivityForResult(params.createIntent(), REQ_MEDIA);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "File picker not available", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // The APK loads the live hosted website. The native APK must therefore
                // not depend on a particular website build to trigger notification permission.
                // Poll the live Supabase session and request notification permission once
                // when a CUSTOMER session is detected after login/create-account.
                scheduleCustomerNotificationPermissionCheck();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return handleExternal(request.getUrl().toString()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return handleExternal(url); }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (isAllowedApkDownloadUrl(url)) {
                downloadApk(url);
            } else if (url != null) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "Unable to open download link", Toast.LENGTH_SHORT).show(); }
            }
        });
        loadLatestWebsite();
        root.postDelayed(this::checkForNativeUpdate, 1800);
    }

    /**
     * Always ask the hosted site for the newest document when the APK starts.
     * This bypasses WebView HTTP cache without clearing cookies, local storage,
     * Supabase sessions, or customer data. The website/service-worker still
     * provides its own offline fallback when the network is unavailable.
     */
    private void loadLatestWebsite() {
        String refreshUrl = "https://adjservices.pages.dev/?apk_refresh=" + System.currentTimeMillis();
        webView.loadUrl(refreshUrl);
    }

    private boolean isAllowedApkDownloadUrl(String url) {
        if (url == null) return false;
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            String path = uri.getPath() == null ? "" : uri.getPath();
            boolean https = "https".equalsIgnoreCase(uri.getScheme());
            boolean pages = "adjservices.pages.dev".equalsIgnoreCase(host);
            boolean githubLatest = "github.com".equalsIgnoreCase(host)
                    && path.startsWith("/amarkumawat6676-ctrl/adj-services-apk/releases/")
                    && path.endsWith("/ADJ-SERVICES.apk");
            return https && (pages || githubLatest);
        } catch (Exception e) {
            return false;
        }
    }

    private void checkForNativeUpdate() {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(UPDATE_MANIFEST_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(6000); c.setReadTimeout(6000); c.setRequestMethod("GET");
                c.setRequestProperty("Cache-Control", "no-cache");
                if (c.getResponseCode() != 200) return;
                InputStream in = c.getInputStream();
                byte[] buf = new byte[8192]; StringBuilder out = new StringBuilder(); int n;
                while ((n = in.read(buf)) > 0) out.append(new String(buf, 0, n, java.nio.charset.StandardCharsets.UTF_8));
                in.close();
                JSONObject j = new JSONObject(out.toString());
                String latest = j.optString("latestVersion", "").trim();
                String url = j.optString("downloadUrl", "").trim();
                String message = j.optString("message", "A new ADJ SERVICES app update is available.");
                boolean force = j.optBoolean("forceUpdate", false);
                String current = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
                if (!latest.isEmpty() && isNewerVersion(current, latest) && isAllowedApkDownloadUrl(url)) {
                    runOnUiThread(() -> showUpdateDialog(latest, url, message, force));
                }
            } catch (Exception ignored) { }
            finally { if (c != null) c.disconnect(); }
        }).start();
    }

    private boolean isNewerVersion(String current, String latest) {
        try {
            String[] a=current.split("\\."), b=latest.split("\\.");
            int m=Math.max(a.length,b.length);
            for(int i=0;i<m;i++){ int x=i<a.length?Integer.parseInt(a[i].replaceAll("[^0-9].*","")):0; int y=i<b.length?Integer.parseInt(b[i].replaceAll("[^0-9].*","")):0; if(y>x)return true; if(y<x)return false; }
        } catch(Exception e){ return !current.equals(latest); }
        return false;
    }

    private void showUpdateDialog(String latest, String url, String message, boolean force) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("ADJ SERVICES Update");
        b.setMessage(message + "\n\nCurrent version: " + getVersionName() + "\nNew version: " + latest);
        b.setPositiveButton("UPDATE NOW", (d,w) -> downloadApk(url));
        if (!force) b.setNegativeButton("LATER", null);
        AlertDialog dialog=b.create();
        dialog.setCanceledOnTouchOutside(!force); dialog.setCancelable(!force); dialog.show();
    }

    private String getVersionName(){ try{return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception e){return "0.0";} }

    private void downloadApk(String url) {
        if (!isAllowedApkDownloadUrl(url)) { Toast.makeText(this, "Invalid update link", Toast.LENGTH_SHORT).show(); return; }
        try {
            DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));
            r.setTitle("ADJ SERVICES Update"); r.setDescription("Downloading the latest ADJ SERVICES app");
            r.setMimeType("application/vnd.android.package-archive");
            r.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI|DownloadManager.Request.NETWORK_MOBILE);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "ADJ-SERVICES-latest.apk");
            long id=dm.enqueue(r); getSharedPreferences(PREFS,MODE_PRIVATE).edit().putLong(PREF_DOWNLOAD_ID,id).apply();
            Toast.makeText(this,"Update download started.",Toast.LENGTH_LONG).show();
        } catch(Exception e){ Toast.makeText(this,"Download failed: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void checkCompletedUpdateDownload(){
        long id=getSharedPreferences(PREFS,MODE_PRIVATE).getLong(PREF_DOWNLOAD_ID,-1); if(id<0)return;
        try{ DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE); DownloadManager.Query q=new DownloadManager.Query().setFilterById(id); android.database.Cursor c=dm.query(q);
            if(c!=null && c.moveToFirst()){ int status=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                if(status==DownloadManager.STATUS_SUCCESSFUL){ String uri=c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI)); getSharedPreferences(PREFS,MODE_PRIVATE).edit().remove(PREF_DOWNLOAD_ID).apply(); c.close(); installApk(Uri.parse(uri)); return; }
                if(status==DownloadManager.STATUS_FAILED){ getSharedPreferences(PREFS,MODE_PRIVATE).edit().remove(PREF_DOWNLOAD_ID).apply(); }
            } if(c!=null)c.close();
        }catch(Exception ignored){}
    }

    private void installApk(Uri localUri){
        try{ Uri contentUri=localUri; if("file".equalsIgnoreCase(localUri.getScheme())) contentUri=FileProvider.getUriForFile(this,"in.adjservices.app.fileprovider",new java.io.File(localUri.getPath()));
            Intent i=new Intent(Intent.ACTION_VIEW); i.setDataAndType(contentUri,"application/vnd.android.package-archive"); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
            if(Build.VERSION.SDK_INT>=26 && !getPackageManager().canRequestPackageInstalls()){
                new AlertDialog.Builder(this).setTitle("Allow app updates").setMessage("Android needs permission to install the ADJ SERVICES update. Please allow it once in the next screen.").setPositiveButton("OPEN SETTINGS",(d,w)->{Intent s=new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName()));startActivity(s);}).setNegativeButton("CANCEL",null).show();
                return;
            } startActivity(i);
        }catch(Exception e){Toast.makeText(this,"Unable to open the update installer",Toast.LENGTH_LONG).show();}
    }

    private class ADJNativeBridge {
        @JavascriptInterface
        public String getAppVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "0.0";
            }
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> requestNotificationPermissionOnce());
        }

        @JavascriptInterface
        public void downloadLatestApk(String url) {
            downloadApk(url);
        }
    }

    private void scheduleCustomerNotificationPermissionCheck() {
        if (Build.VERSION.SDK_INT < 33 || hasPermission(Manifest.permission.POST_NOTIFICATIONS)) return;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean(PREF_NOTIFICATION_REQUESTED, false)) return;

        final long deadline = System.currentTimeMillis() + 30000L;
        final Runnable[] poll = new Runnable[1];
        poll[0] = () -> {
            if (isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            if (p.getBoolean(PREF_NOTIFICATION_REQUESTED, false) || hasPermission(Manifest.permission.POST_NOTIFICATIONS)) return;

            String js = "(async function(){try{" +
                    "if(typeof currentProfile !== 'undefined' && currentProfile && String(currentProfile.role||'').toLowerCase()==='customer') return 'customer';" +
                    "if(typeof supabaseClient !== 'undefined' && supabaseClient && supabaseClient.auth){" +
                    "var r=await supabaseClient.auth.getSession(); var sess=r&&r.data&&r.data.session;" +
                    "if(sess&&sess.user){var q=await supabaseClient.from('profiles').select('role').eq('id',sess.user.id).maybeSingle();" +
                    "if(q&&q.data&&String(q.data.role||'').toLowerCase()==='customer') return 'customer';}}" +
                    "}catch(e){} return '';})()";

            webView.evaluateJavascript(js, value -> {
                if ("\"customer\"".equals(value)) {
                    requestNotificationPermissionOnce();
                } else if (System.currentTimeMillis() < deadline) {
                    webView.postDelayed(poll[0], 1000L);
                }
            });
        };
        webView.postDelayed(poll[0], 1200L);
    }

    private void requestNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (hasPermission(Manifest.permission.POST_NOTIFICATIONS)) return;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean(PREF_NOTIFICATION_REQUESTED, false)) return;
        prefs.edit().putBoolean(PREF_NOTIFICATION_REQUESTED, true).apply();
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        if (request == null) return;
        List<String> needed = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && !hasPermission(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA);
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && !hasPermission(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (needed.isEmpty()) {
            request.grant(request.getResources());
        } else {
            pendingWebPermission = request;
            requestPermissions(needed.toArray(new String[0]), REQ_CAMERA_AUDIO);
        }
    }

    private boolean hasPermission(String permission) { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED; }
    private boolean hasLocationPermission() { return hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) || hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION); }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean ok = hasLocationPermission();
            if (pendingGeoCallback != null) pendingGeoCallback.invoke(pendingGeoOrigin, ok, false);
            pendingGeoCallback = null; pendingGeoOrigin = null;
        } else if (requestCode == REQ_CAMERA_AUDIO) {
            PermissionRequest request = pendingWebPermission;
            pendingWebPermission = null;
            if (request != null) {
                boolean ok = true;
                for (String resource : request.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && !hasPermission(Manifest.permission.CAMERA)) ok = false;
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && !hasPermission(Manifest.permission.RECORD_AUDIO)) ok = false;
                }
                if (ok) request.grant(request.getResources()); else request.deny();
            }
        } else if (requestCode == REQ_NOTIFICATION) {
            // Result intentionally requires no follow-up UI.
        }
    }

    private boolean handleExternal(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        boolean external = scheme.equals("tel") || scheme.equals("mailto") || scheme.equals("whatsapp") || scheme.equals("geo") ||
                url.startsWith("https://wa.me/") || url.startsWith("https://maps.google.com/") || url.startsWith("https://www.google.com/maps/");
        if (!external) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "Required app is not installed", Toast.LENGTH_SHORT).show(); }
        return true;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_MEDIA && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            pendingFileChooserParams = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.loadUrl("about:blank"); webView.destroy(); }
        super.onDestroy();
    }
}
