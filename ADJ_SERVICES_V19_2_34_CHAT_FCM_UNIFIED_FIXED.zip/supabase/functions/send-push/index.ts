// ADJ SERVICES — unified push sender
// Customer + Admin/Staff + Technician
//
// Supabase Edge Function name: send-push
//
// Required secrets:
//   ADJ_WEBHOOK_SECRET
//   FIREBASE_PROJECT_ID
//   FIREBASE_CLIENT_EMAIL
//   FIREBASE_PRIVATE_KEY
//   VAPID_PUBLIC_KEY
//   VAPID_PRIVATE_KEY
// Optional fallback:
//   FIREBASE_SERVICE_ACCOUNT_JSON
//
// Supabase runtime secrets:
//   SUPABASE_URL
//   SUPABASE_SERVICE_ROLE_KEY (or SUPABASE_SECRET_KEY)

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { SignJWT, importPKCS8 } from "npm:jose@5.10.0";
import webpush from "npm:web-push@3.6.7";

type NotificationRecord = {
  id?: string;
  user_id?: string;
  title?: string;
  message?: string;
  type?: string;
  booking_id?: string | null;
  url?: string | null;
  target_page?: string | null;
  target_params?: Record<string, unknown> | null;
  notification_type?: string | null;
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRole =
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ??
  Deno.env.get("SUPABASE_SECRET_KEY")!;

const supabase = createClient(supabaseUrl, serviceRole);

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json",
      "access-control-allow-origin": "*",
    },
  });

function getWebhookSecret(req: Request) {
  return req.headers.get("x-adj-webhook-secret") || "";
}

function isAuthorized(req: Request) {
  const configured = Deno.env.get("ADJ_WEBHOOK_SECRET") || "";
  if (configured && getWebhookSecret(req) === configured) return true;

  const auth = req.headers.get("authorization") || "";
  const bearer = auth.replace(/^Bearer\s+/i, "").trim();
  const apikey = req.headers.get("apikey") || "";

  // Allow controlled server-side calls made with the Supabase service key.
  return !!serviceRole && (bearer === serviceRole || apikey === serviceRole);
}

async function getFirebaseServiceAccount() {
  const jsonSecret = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON");
  if (jsonSecret) {
    try {
      const sa = JSON.parse(jsonSecret);
      if (sa.project_id && sa.client_email && sa.private_key) return sa;
    } catch (_) {
      // Continue to the separate-secret path.
    }
  }

  const projectId = Deno.env.get("FIREBASE_PROJECT_ID") || "";
  const clientEmail = Deno.env.get("FIREBASE_CLIENT_EMAIL") || "";
  const privateKey = Deno.env.get("FIREBASE_PRIVATE_KEY") || "";

  if (!projectId || !clientEmail || !privateKey) return null;

  return {
    project_id: projectId,
    client_email: clientEmail,
    private_key: privateKey,
  };
}

async function firebaseAccessToken(sa: {
  project_id: string;
  client_email: string;
  private_key: string;
}) {
  const now = Math.floor(Date.now() / 1000);
  const privateKey = String(sa.private_key).replace(/\\n/g, "\n");
  const key = await importPKCS8(privateKey, "RS256");

  const assertion = await new SignJWT({
    scope: "https://www.googleapis.com/auth/firebase.messaging",
  })
    .setProtectedHeader({ alg: "RS256", typ: "JWT" })
    .setIssuer(sa.client_email)
    .setAudience("https://oauth2.googleapis.com/token")
    .setIssuedAt(now)
    .setExpirationTime(now + 3600)
    .sign(key);

  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body:
      "grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=" +
      encodeURIComponent(assertion),
  });

  const data = await r.json();
  if (!r.ok || !data.access_token) {
    throw new Error(`Firebase OAuth failed: ${r.status} ${JSON.stringify(data)}`);
  }

  return data.access_token as string;
}

async function sendFcm(record: NotificationRecord) {
  const sa = await getFirebaseServiceAccount();

  if (!sa) {
    return {
      sent: 0,
      failed: 0,
      skipped: true,
      reason: "Firebase secrets missing",
    };
  }

  const { data: rows, error } = await supabase
    .from("fcm_tokens")
    .select("id,token")
    .eq("user_id", record.user_id!)
    .eq("is_active", true)
    .not("token", "is", null);

  if (error) throw error;

  // One physical device can have multiple rows after reinstall/token refresh.
  // Send to every active token, but never send twice to the exact same token.
  const unique = new Map<string, { id: string; token: string }>();
  for (const row of rows || []) {
    const token = String(row.token || "").trim();
    if (token && !unique.has(token)) {
      unique.set(token, { id: row.id, token });
    }
  }

  if (!unique.size) {
    return { sent: 0, failed: 0, skipped: true, reason: "no active FCM token" };
  }

  const access = await firebaseAccessToken(sa);
  const endpoint =
    `https://fcm.googleapis.com/v1/projects/${encodeURIComponent(sa.project_id)}/messages:send`;

  let sent = 0;
  let failed = 0;

  for (const row of unique.values()) {
    const message = {
      message: {
        token: row.token,

        // DATA-ONLY FCM. ADJFirebaseMessagingService renders the tray
        // notification and handles the deep-link on Android.
        data: {
          title: String(record.title || "ADJ SERVICES"),
          body: String(record.message || "You have a new update."),
          url: String(record.url || "https://adjservices.pages.dev/"),
          type: String(record.type || record.notification_type || "general"),
          booking_id: String(record.booking_id || ""),
          notification_id: String(record.id || ""),
        },

        android: {
          priority: "HIGH",
        },
      },
    };

    const r = await fetch(endpoint, {
      method: "POST",
      headers: {
        authorization: `Bearer ${access}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(message),
    });

    if (r.ok) {
      sent++;
      continue;
    }

    failed++;
    const responseBody = await r.text();

    // FCM HTTP v1 uses UNREGISTERED for dead/expired registration tokens.
    if (r.status === 404 || responseBody.includes("UNREGISTERED")) {
      await supabase.from("fcm_tokens").delete().eq("id", row.id);
    }

    console.error("FCM send failed", r.status, responseBody);
  }

  return {
    sent,
    failed,
    skipped: false,
    token_count: unique.size,
  };
}

async function sendWebPush(record: NotificationRecord) {
  const pub = Deno.env.get("VAPID_PUBLIC_KEY");
  const priv = Deno.env.get("VAPID_PRIVATE_KEY");
  const subject =
    Deno.env.get("VAPID_SUBJECT") || "mailto:admin@adjservices.in";

  if (!pub || !priv) {
    return {
      sent: 0,
      failed: 0,
      skipped: true,
      reason: "VAPID secrets missing",
    };
  }

  webpush.setVapidDetails(subject, pub, priv);

  const { data: subs, error } = await supabase
    .from("push_subscriptions")
    .select("id,endpoint,p256dh,auth")
    .eq("user_id", record.user_id!);

  if (error) throw error;

  if (!subs?.length) {
    return {
      sent: 0,
      failed: 0,
      skipped: true,
      reason: "No Web Push subscription",
    };
  }

  const payload = JSON.stringify({
    title: record.title || "ADJ SERVICES",
    body: record.message || "You have a new update.",
    url: record.url || "/",
    type: record.type || record.notification_type || "general",
    booking_id: record.booking_id || null,
  });

  let sent = 0;
  let failed = 0;

  for (const sub of subs) {
    try {
      await webpush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: { p256dh: sub.p256dh, auth: sub.auth },
        },
        payload,
      );
      sent++;
    } catch (e) {
      failed++;
      const status = Number((e as any)?.statusCode || 0);

      if (status === 404 || status === 410) {
        await supabase.from("push_subscriptions").delete().eq("id", sub.id);
      }

      console.error("Web Push send failed", status, e);
    }
  }

  return { sent, failed, skipped: false };
}

async function resolveDeepLink(record: NotificationRecord) {
  if (record.url) return String(record.url);

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", record.user_id!)
    .maybeSingle();

  const role = String(profile?.role || "customer").toLowerCase();

  const portal =
    role === "admin" || role === "staff"
      ? "admin.html"
      : role === "technician"
        ? "technician.html"
        : "customer.html";

  const type = String(
    record.notification_type || record.type || "general",
  ).toLowerCase();

  const params = new URLSearchParams();
  params.set("notification", "1");
  params.set("type", type);

  if (record.booking_id) {
    params.set("booking_id", String(record.booking_id));
  }

  if (type === "chat") {
    params.set("chat", "1");
  }

  return `https://adjservices.pages.dev/${portal}?${params.toString()}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204 });

  try {
    if (!isAuthorized(req)) {
      return json({ success: false, error: "Unauthorized" }, 401);
    }

    const payload = await req.json();
    const record: NotificationRecord | undefined = payload?.record;

    if (!record?.user_id) {
      return json(
        { success: false, error: "Notification user_id is missing" },
        400,
      );
    }

    record.url = await resolveDeepLink(record);

    const [fcm, web] = await Promise.all([
      sendFcm(record),
      sendWebPush(record),
    ]);

    return json({
      success: true,
      notification_id: record.id || null,
      user_id: record.user_id,
      title: record.title || "ADJ SERVICES",
      message: record.message || "",
      deep_link: record.url,
      fcm,
      web_push: web,
      total_sent: (fcm.sent || 0) + (web.sent || 0),
    });
  } catch (e) {
    console.error("send-push error", e);
    return json(
      {
        success: false,
        error: String((e as any)?.message || e),
      },
      500,
    );
  }
});
