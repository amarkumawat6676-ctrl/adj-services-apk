-- ADJ SERVICES V19.2.33 — CHAT REALTIME RELIABILITY PATCH
-- Run once in Supabase SQL Editor. Safe/idempotent.

alter table public.service_chats replica identity full;

do $$
begin
  alter publication supabase_realtime add table public.service_chats;
exception
  when duplicate_object then null;
  when undefined_object then null;
end $$;

-- Customer/admin chat rows must remain readable by the intended participant/admin.
alter table public.service_chats enable row level security;

drop policy if exists "ADJ chat select" on public.service_chats;
create policy "ADJ chat select"
on public.service_chats
for select to authenticated
using (user_id = auth.uid() or public.get_my_role() = 'admin');

drop policy if exists "ADJ chat insert" on public.service_chats;
create policy "ADJ chat insert"
on public.service_chats
for insert to authenticated
with check (sender_id = auth.uid() and (user_id = auth.uid() or public.get_my_role() = 'admin'));

drop policy if exists "ADJ chat update" on public.service_chats;
create policy "ADJ chat update"
on public.service_chats
for update to authenticated
using (user_id = auth.uid() or public.get_my_role() = 'admin')
with check (user_id = auth.uid() or public.get_my_role() = 'admin');

notify pgrst, 'reload schema';
