ADJ SERVICES V14.4

Fixes:
- Customer login triggers automatic latest-version check.
- Existing logged-in customer sessions also check after app reopen.
- Customer Profile keeps Check App Version.
- Update download uses native Android DownloadManager through ADJNative.
- APK version is 14.4 (versionCode 17).
- Website update source remains https://adjservices.pages.dev/app-version.json.
