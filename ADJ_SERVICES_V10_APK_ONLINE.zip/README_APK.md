
## ADJ SERVICES Online Website APK
This version loads the live Cloudflare Pages website:
https://adjservices.pages.dev

The Supabase backend is unchanged. Future frontend changes deployed to the same
Cloudflare Pages URL will be reflected in this APK without rebuilding the APK,
as long as the Android wrapper itself does not need native changes.
