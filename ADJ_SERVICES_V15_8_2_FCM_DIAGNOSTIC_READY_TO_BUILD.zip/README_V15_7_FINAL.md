# ADJ SERVICES V15.7 final-ready

- VersionName 15.7 / versionCode 30.
- Native FCM registration now receives the authenticated Supabase session directly from the hosted page through the Android bridge, avoiding WebView localStorage parsing as the primary path.
- Existing token-based FCM sender remains compatible.
- APK update checker uses numeric versionCode when supplied and verifies package name, versionCode and signing certificate before invoking Android installer.
- `undefined` is rejected as an app version value.
- No Firebase service-account private key is bundled in the APK.
