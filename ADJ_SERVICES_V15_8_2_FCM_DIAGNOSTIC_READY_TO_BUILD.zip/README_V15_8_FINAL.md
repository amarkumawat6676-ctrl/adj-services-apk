# ADJ SERVICES V15.8.1.1.1.1 — FINAL READY BUILD

- Android package: `in.adjservices.app`
- versionName: `15.8.1.1`
- versionCode: `31`
- Native Firebase FCM token registration uses the live Supabase Auth session handoff from the WebView.
- FCM background notification channel is configured as high importance.
- Native updater checks GitHub Releases, validates package/version/signing certificate, then opens Android's in-place installer.
- GitHub Actions builds the signed APK and publishes `ADJ-SERVICES.apk` to the matching GitHub Release.
- Firebase service-account private key is not included in the APK.
