# ADJ SERVICES — Permanent APK Update System

This build adds a native Android update checker to the existing WebView APK.

- Checks `https://adjservices.pages.dev/app-version.json` shortly after launch.
- Compares the installed native version with `latestVersion`.
- Shows an `UPDATE NOW` popup when a newer version is published.
- Downloads the APK from the fixed `downloadUrl`.
- Opens the Android package installer when the download completes.
- Uses the same application ID and release keystore, so future signed releases can update the installed app.
- Does not request notification/location/camera/microphone permissions at startup.
- Android's unknown-app-source install permission may need to be allowed once before an APK update can be installed; this cannot be silently bypassed by a normal Android app.

## Future release flow

Keep the fixed APK URL and manifest URL stable. Publish the new signed APK at:
`https://adjservices.pages.dev/downloads/ADJ-SERVICES.apk`

Then update `app-version.json` with the new version number. Customer APKs will detect the higher version and show the update popup automatically.
