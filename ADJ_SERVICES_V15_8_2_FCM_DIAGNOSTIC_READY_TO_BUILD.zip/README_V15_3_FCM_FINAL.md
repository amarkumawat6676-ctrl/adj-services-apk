# ADJ SERVICES V15.3 — Native FCM + Existing Web Push

This package is the final source-side integration for native Android push notifications.

## What is fixed
- Android FCM SDK is added to the APK source.
- Android registration token is generated and exposed to the WebView through `ADJNative.requestFcmToken()`.
- The logged-in customer WebView saves the FCM token into `public.fcm_tokens`.
- FCM token rotation is pushed back to the WebView.
- Android notification channel `adj_services_alerts` is HIGH importance with default sound.
- Existing PWA/Web Push (`push_subscriptions`) remains intact.
- `send-push` sends to both FCM (APK) and Web Push (PWA/browser).

## Firebase Android config
The supplied `google-services.json` has been installed at `app/google-services.json`.
It matches the Android package `in.adjservices.app` and Firebase project `adj-services`.

Do NOT put a Firebase service-account private key into the APK.

## Supabase setup
1. Run `SUPABASE_FCM_V15_3_FINAL.sql`.
2. In Supabase Edge Function secrets add:
   - `FIREBASE_SERVICE_ACCOUNT_JSON` = the complete Firebase service-account JSON for the same Firebase project.
   - Keep existing `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, and `VAPID_SUBJECT`.
3. Deploy `supabase/functions/send-push`.
4. Point the existing database webhook for notification inserts to the `send-push` function. Its payload must contain the inserted notification row under `record`.

## Important
The Firebase service-account JSON is backend-only. Never put it in `customer.html`, the APK, GitHub, or the browser.

The existing ZIP also contains a VAPID private key in a setup text file. Because private credentials have been included in a distributable ZIP, rotate that VAPID private key after migration and update the Supabase secret.

## Build
This project already has the ADJ release signing configuration from the supplied source package. Add the real `app/google-services.json`, then build the release APK with Android Studio/Gradle.

The final APK version in this source is `15.3` (versionCode `26`).
