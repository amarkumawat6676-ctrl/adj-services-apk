ADJ SERVICES V19.2.25 — BOOKING ALERTS + CHAT

Admin booking status updates now use one secure alert flow.
The customer receives the same message in:
1. ADJ Notifications
2. Existing ADJ Chat Box
3. Phone notification when Web Push is configured and permission is granted

Confirmed message:
Booking Confirmed
Your service booking #ADJ123 has been confirmed. Technician details will be shared soon.

Other status messages:
Technician Assigned
Technician On The Way
Work Started
Service Completed

Run SUPABASE_V19_2_25_BOOKING_ALERTS.sql once.
For background phone push, follow PUSH_SETUP_V19_2_25.md.
No WhatsApp API is required.
