// ADJ SERVICES V19.2.25
// Supabase Edge Function: send Web Push when a notification row is inserted.
// Deploy with: supabase functions deploy adj-push-notification
// Required secrets:
// SUPABASE_URL
// SUPABASE_SERVICE_ROLE_KEY
// VAPID_PUBLIC_KEY
// VAPID_PRIVATE_KEY
// VAPID_SUBJECT (example: mailto:admin@yourdomain)

import webpush from "npm:web-push@3.6.7";
import { createClient } from "npm:@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const vapidPublic = Deno.env.get("VAPID_PUBLIC_KEY")!;
const vapidPrivate = Deno.env.get("VAPID_PRIVATE_KEY")!;
const vapidSubject = Deno.env.get("VAPID_SUBJECT") || "mailto:admin@example.com";

webpush.setVapidDetails(vapidSubject, vapidPublic, vapidPrivate);

const admin = createClient(supabaseUrl, serviceRoleKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  try {
    const payload = await req.json();
    const row = payload?.record;

    if (!row?.user_id) {
      return Response.json({ ok: true, skipped: "missing user_id" });
    }

    const { data: subscriptions, error } = await admin
      .from("push_subscriptions")
      .select("id,endpoint,p256dh,auth")
      .eq("user_id", row.user_id);

    if (error) throw error;

    const results = [];

    for (const sub of subscriptions || []) {
      try {
        await webpush.sendNotification(
          {
            endpoint: sub.endpoint,
            keys: {
              p256dh: sub.p256dh,
              auth: sub.auth,
            },
          },
          JSON.stringify({
            title: row.title || "ADJ SERVICES",
            body: row.message || "You have a new update.",
            url: "./customer.html?open=chat",
            tag: row.booking_id ? `booking-${row.booking_id}` : `notification-${row.id}`,
          }),
          { TTL: 60 * 60 * 24 }
        );
        results.push({ id: sub.id, ok: true });
      } catch (e) {
        const status = Number((e as { statusCode?: number })?.statusCode || 0);
        // Expired/unregistered browser subscriptions should be removed.
        if (status === 404 || status === 410) {
          await admin.from("push_subscriptions").delete().eq("id", sub.id);
        }
        results.push({ id: sub.id, ok: false, status, error: String(e) });
      }
    }

    return Response.json({ ok: true, sent: results });
  } catch (e) {
    console.error(e);
    return Response.json(
      { ok: false, error: String(e) },
      { status: 500 }
    );
  }
});
