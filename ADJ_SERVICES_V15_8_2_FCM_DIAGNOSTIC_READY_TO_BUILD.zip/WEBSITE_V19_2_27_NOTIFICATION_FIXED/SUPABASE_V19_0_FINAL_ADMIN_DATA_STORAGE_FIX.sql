-- ADJ SERVICES V19.0 FINAL ADMIN DATA + STORAGE FIX
-- Bookings + Technicians + Logo + Gallery + Welcome Images
-- Run this ONCE in Supabase SQL Editor.

begin;

-- ---------------------------------------------------------
-- 1) Safe admin checker. SECURITY DEFINER avoids RLS recursion.
-- ---------------------------------------------------------
drop function if exists public.adj_is_admin();
create or replace function public.adj_is_admin()
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = auth.uid()
      and lower(coalesce(p.role::text,'')) = 'admin'
  );
$$;
revoke all on function public.adj_is_admin() from public;
grant execute on function public.adj_is_admin() to authenticated;

-- ---------------------------------------------------------
-- 2) Website settings columns required by the Admin panel.
-- ---------------------------------------------------------
alter table public.website_settings
  add column if not exists gallery_urls jsonb default '[]'::jsonb;

alter table public.website_settings
  add column if not exists welcome_gallery_urls jsonb default '[]'::jsonb;

-- ---------------------------------------------------------
-- 3) Security-definer Admin data RPCs.
-- These bypass table RLS safely after verifying the Admin role.
-- ---------------------------------------------------------

drop function if exists public.admin_get_bookings();

create or replace function public.admin_get_bookings()
returns jsonb
language plpgsql
security definer
stable
set search_path = public
as $$
begin
  if not public.adj_is_admin() then
    raise exception 'Admin access required';
  end if;

  return coalesce(
    (select jsonb_agg(to_jsonb(b))
     from public.bookings b),
    '[]'::jsonb
  );
end;
$$;

revoke all on function public.admin_get_bookings() from public;
grant execute on function public.admin_get_bookings() to authenticated;


drop function if exists public.admin_get_technicians();

create or replace function public.admin_get_technicians()
returns jsonb
language plpgsql
security definer
stable
set search_path = public
as $$
begin
  if not public.adj_is_admin() then
    raise exception 'Admin access required';
  end if;

  return coalesce(
    (select jsonb_agg(
       to_jsonb(t) ||
       jsonb_build_object(
         'profiles',
         coalesce(to_jsonb(p), '{}'::jsonb)
       )
     )
     from public.technicians t
     left join public.profiles p on p.id = t.id),
    '[]'::jsonb
  );
end;
$$;

revoke all on function public.admin_get_technicians() from public;
grant execute on function public.admin_get_technicians() to authenticated;


-- ---------------------------------------------------------
-- 4) Admin read access to profiles / technicians / bookings.
-- Existing customer/technician policies remain; these are
-- additional permissive admin policies.
-- ---------------------------------------------------------
grant select on public.profiles to authenticated;
grant select on public.technicians to authenticated;
grant select on public.bookings to authenticated;

drop policy if exists "ADJ V19 admin profiles read" on public.profiles;
create policy "ADJ V19 admin profiles read"
on public.profiles
for select to authenticated
using (public.adj_is_admin());

drop policy if exists "ADJ V19 admin technicians read" on public.technicians;
create policy "ADJ V19 admin technicians read"
on public.technicians
for select to authenticated
using (public.adj_is_admin());

drop policy if exists "ADJ V19 admin bookings read" on public.bookings;
create policy "ADJ V19 admin bookings read"
on public.bookings
for select to authenticated
using (public.adj_is_admin());

-- ---------------------------------------------------------
-- 5) Admin website-settings read/write.
-- ---------------------------------------------------------
grant select, insert, update on public.website_settings to authenticated;

drop policy if exists "ADJ V19 admin website settings read" on public.website_settings;
create policy "ADJ V19 admin website settings read"
on public.website_settings
for select to authenticated
using (public.adj_is_admin());

drop policy if exists "ADJ V19 admin website settings insert" on public.website_settings;
create policy "ADJ V19 admin website settings insert"
on public.website_settings
for insert to authenticated
with check (public.adj_is_admin());

drop policy if exists "ADJ V19 admin website settings update" on public.website_settings;
create policy "ADJ V19 admin website settings update"
on public.website_settings
for update to authenticated
using (public.adj_is_admin())
with check (public.adj_is_admin());

-- ---------------------------------------------------------
-- 6) Storage bucket for logo / hero / offer / gallery / welcome.
-- ---------------------------------------------------------
insert into storage.buckets (id,name,public)
values ('site-assets','site-assets',true)
on conflict (id) do update set public=true;

-- Public image URLs must be readable by customer app.
drop policy if exists "ADJ V19 site assets public read" on storage.objects;
create policy "ADJ V19 site assets public read"
on storage.objects
for select to public
using (bucket_id='site-assets');

-- Admin upload.
drop policy if exists "ADJ V19 admin site assets upload" on storage.objects;
create policy "ADJ V19 admin site assets upload"
on storage.objects
for insert to authenticated
with check (
  bucket_id='site-assets'
  and public.adj_is_admin()
);

-- Admin replace/update.
drop policy if exists "ADJ V19 admin site assets update" on storage.objects;
create policy "ADJ V19 admin site assets update"
on storage.objects
for update to authenticated
using (
  bucket_id='site-assets'
  and public.adj_is_admin()
)
with check (
  bucket_id='site-assets'
  and public.adj_is_admin()
);

-- Admin delete.
drop policy if exists "ADJ V19 admin site assets delete" on storage.objects;
create policy "ADJ V19 admin site assets delete"
on storage.objects
for delete to authenticated
using (
  bucket_id='site-assets'
  and public.adj_is_admin()
);

notify pgrst, 'reload schema';

commit;
