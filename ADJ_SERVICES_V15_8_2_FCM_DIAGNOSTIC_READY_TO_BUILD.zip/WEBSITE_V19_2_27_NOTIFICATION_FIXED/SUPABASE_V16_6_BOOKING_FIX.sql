-- ADJ SERVICES V16.6 CUSTOMER BOOKING FIX
-- Run this once in Supabase SQL Editor.
-- Creates a secure customer booking RPC and refreshes bookings permissions.

begin;

-- Customer booking insert permissions.
alter table public.bookings enable row level security;
grant select, insert, update on public.bookings to authenticated;

drop policy if exists "ADJ V16 customer booking insert" on public.bookings;
create policy "ADJ V16 customer booking insert"
on public.bookings for insert to authenticated
with check (customer_id = auth.uid() or public.get_my_role() = 'admin');

drop policy if exists "ADJ V16 customer booking read" on public.bookings;
create policy "ADJ V16 customer booking read"
on public.bookings for select to authenticated
using (customer_id = auth.uid() or technician_id = auth.uid() or public.get_my_role() = 'admin');

-- Secure RPC: the customer ID always comes from auth.uid(), never from the browser.
create or replace function public.customer_create_booking(
  p_booking_code text,
  p_service_name text,
  p_customer_name text,
  p_customer_phone text,
  p_address text,
  p_appliance text,
  p_problem text,
  p_preferred_date date,
  p_preferred_time time,
  p_estimated_price numeric default 0
)
returns public.bookings
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row public.bookings;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  insert into public.bookings (
    booking_code,
    customer_id,
    service_name,
    customer_name,
    customer_phone,
    address,
    appliance,
    problem,
    preferred_date,
    preferred_time,
    status,
    estimated_price
  ) values (
    p_booking_code,
    auth.uid(),
    coalesce(nullif(trim(p_service_name),''),'Service'),
    coalesce(nullif(trim(p_customer_name),''),'Customer'),
    coalesce(p_customer_phone,''),
    coalesce(nullif(trim(p_address),''),'Jaipur'),
    coalesce(nullif(trim(p_appliance),''),'General'),
    coalesce(nullif(trim(p_problem),''),'Not specified'),
    p_preferred_date,
    p_preferred_time,
    'Pending',
    coalesce(p_estimated_price,0)
  ) returning * into v_row;

  return v_row;
end;
$$;

revoke all on function public.customer_create_booking(text,text,text,text,text,text,text,date,time,numeric) from public;
grant execute on function public.customer_create_booking(text,text,text,text,text,text,text,date,time,numeric) to authenticated;

notify pgrst, 'reload schema';
commit;
