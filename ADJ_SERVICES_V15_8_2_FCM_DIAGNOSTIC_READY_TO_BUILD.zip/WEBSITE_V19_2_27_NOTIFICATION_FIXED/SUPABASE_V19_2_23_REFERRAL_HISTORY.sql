-- ADJ SERVICES V19.2.23 — REFER & EARN HISTORY
-- Shows each customer referred by the logged-in customer:
-- 1) account created
-- 2) completed service count/date
-- 3) referral points actually credited
-- No data deletion. Safe additive migration.

BEGIN;

CREATE OR REPLACE FUNCTION public.customer_get_referral_history()
RETURNS TABLE(
  referred_customer_id uuid,
  referred_customer_name text,
  referred_customer_phone text,
  account_created_at timestamptz,
  completed_services bigint,
  first_completed_at timestamptz,
  last_completed_at timestamptz,
  reward_points bigint
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me uuid := auth.uid();
BEGIN
  IF me IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = me
      AND lower(coalesce(role,'')) = 'customer'
  ) THEN
    RAISE EXCEPTION 'Customer account required';
  END IF;

  RETURN QUERY
  SELECT
    p.id,
    coalesce(nullif(trim(p.full_name),''),'Customer'),
    coalesce(nullif(trim(p.phone),''),''),
    p.created_at,
    coalesce(bs.completed_services,0)::bigint,
    bs.first_completed_at,
    bs.last_completed_at,
    coalesce(ev.reward_points,0)::bigint
  FROM public.profiles p
  LEFT JOIN LATERAL (
    SELECT
      count(*) FILTER (
        WHERE lower(coalesce(b.status,'')) IN ('completed','complete','service completed')
      ) AS completed_services,
      min(b.created_at) FILTER (
        WHERE lower(coalesce(b.status,'')) IN ('completed','complete','service completed')
      ) AS first_completed_at,
      max(b.created_at) FILTER (
        WHERE lower(coalesce(b.status,'')) IN ('completed','complete','service completed')
      ) AS last_completed_at
    FROM public.bookings b
    WHERE b.customer_id = p.id
  ) bs ON true
  LEFT JOIN LATERAL (
    SELECT coalesce(sum(e.points) FILTER (WHERE e.event_type='completed_service'),0) AS reward_points
    FROM public.adj_referral_events e
    WHERE e.referrer_id = me
      AND e.referred_customer_id = p.id
  ) ev ON true
  WHERE p.referred_by = me
    AND lower(coalesce(p.role,'')) = 'customer'
  ORDER BY p.created_at DESC;
END;
$$;

REVOKE ALL ON FUNCTION public.customer_get_referral_history() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.customer_get_referral_history() TO authenticated;

COMMIT;
