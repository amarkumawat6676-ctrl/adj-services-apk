-- ADJ SERVICES V19.2.22 — CUSTOMER ACCOUNT UNIQUENESS / SIGNUP HARDENING
-- Safe migration: no DROP TABLE, no data deletion.
-- Rule: one customer account per mobile number AND one account per real Gmail/email.
-- Email remains optional at signup. Phone is required.

BEGIN;

-- Normalize a mobile value to the final 10 digits for Indian numbers.
CREATE OR REPLACE FUNCTION public.adj_normalize_phone(p_phone text)
RETURNS text
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT CASE
    WHEN length(regexp_replace(coalesce(p_phone,''),'\\D','','g')) = 12
         AND left(regexp_replace(coalesce(p_phone,''),'\\D','','g'),2) = '91'
      THEN right(regexp_replace(coalesce(p_phone,''),'\\D','','g'),10)
    ELSE regexp_replace(coalesce(p_phone,''),'\\D','','g')
  END;
$$;

-- Public-safe pre-check used by signup UI. It reveals only whether the
-- supplied identity is already in use, never another customer's details.
CREATE OR REPLACE FUNCTION public.customer_account_identity_check(
  p_phone text,
  p_email text DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_phone text := public.adj_normalize_phone(p_phone);
  v_email text := lower(nullif(trim(coalesce(p_email,'')),''));
  v_phone_exists boolean := false;
  v_email_exists boolean := false;
  v_phone_role text := null;
  v_email_role text := null;
BEGIN
  IF length(v_phone) < 10 THEN
    RAISE EXCEPTION 'Please enter a valid 10-digit mobile number';
  END IF;

  SELECT true, lower(coalesce(role,''))
    INTO v_phone_exists, v_phone_role
  FROM public.profiles
  WHERE public.adj_normalize_phone(phone) = v_phone
  ORDER BY CASE WHEN lower(coalesce(role,''))='customer' THEN 0 ELSE 1 END
  LIMIT 1;

  IF v_email IS NOT NULL THEN
    SELECT true, lower(coalesce(p.role,''))
      INTO v_email_exists, v_email_role
    FROM auth.users u
    LEFT JOIN public.profiles p ON p.id=u.id
    WHERE lower(coalesce(u.email,'')) = v_email
    LIMIT 1;

    IF NOT v_email_exists THEN
      SELECT true, lower(coalesce(role,''))
        INTO v_email_exists, v_email_role
      FROM public.profiles
      WHERE lower(coalesce(email,'')) = v_email
      LIMIT 1;
    END IF;
  END IF;

  RETURN jsonb_build_object(
    'phone_exists', coalesce(v_phone_exists,false),
    'phone_role', v_phone_role,
    'email_exists', coalesce(v_email_exists,false),
    'email_role', v_email_role,
    'exists', coalesce(v_phone_exists,false) OR coalesce(v_email_exists,false)
  );
END;
$$;

REVOKE ALL ON FUNCTION public.customer_account_identity_check(text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.customer_account_identity_check(text,text) TO anon, authenticated;

-- Database-level guard: even if two devices submit signup at the same time,
-- a customer cannot be created with an already-used mobile/email.
CREATE OR REPLACE FUNCTION public.adj_enforce_customer_identity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_phone text := public.adj_normalize_phone(NEW.phone);
  v_email text := lower(nullif(trim(coalesce(NEW.email,'')),''));
  v_other uuid;
BEGIN
  IF lower(coalesce(NEW.role,'')) <> 'customer' THEN
    RETURN NEW;
  END IF;

  IF length(v_phone) < 10 THEN
    RAISE EXCEPTION 'Customer mobile number must be a valid 10-digit number';
  END IF;

  -- Always store the normalized 10-digit Indian mobile when possible.
  NEW.phone := v_phone;

  SELECT id INTO v_other
  FROM public.profiles
  WHERE id <> NEW.id
    AND public.adj_normalize_phone(phone) = v_phone
  LIMIT 1;
  IF v_other IS NOT NULL THEN
    RAISE EXCEPTION 'This mobile number is already registered. Please login instead.';
  END IF;

  IF v_email IS NOT NULL THEN
    SELECT id INTO v_other
    FROM auth.users
    WHERE id <> NEW.id
      AND lower(coalesce(email,'')) = v_email
    LIMIT 1;
    IF v_other IS NOT NULL THEN
      RAISE EXCEPTION 'This Gmail/email is already registered. Please login instead.';
    END IF;

    SELECT id INTO v_other
    FROM public.profiles
    WHERE id <> NEW.id
      AND lower(coalesce(email,'')) = v_email
    LIMIT 1;
    IF v_other IS NOT NULL THEN
      RAISE EXCEPTION 'This Gmail/email is already registered. Please login instead.';
    END IF;

    NEW.email := v_email;
  ELSE
    NEW.email := NULL;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_adj_customer_identity_guard ON public.profiles;
CREATE TRIGGER trg_adj_customer_identity_guard
BEFORE INSERT OR UPDATE OF phone,email,role ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.adj_enforce_customer_identity();

-- Helpful indexes for fast duplicate checks. They do not remove or change data.
CREATE INDEX IF NOT EXISTS profiles_phone_normalized_idx
ON public.profiles (public.adj_normalize_phone(phone));

CREATE INDEX IF NOT EXISTS profiles_email_lower_idx
ON public.profiles (lower(email))
WHERE email IS NOT NULL;

COMMIT;
