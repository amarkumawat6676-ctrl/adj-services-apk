# ADJ SERVICES V19.2.25 — Phone Push Setup

The app now supports:

- Supabase Realtime in-app notification alerts
- Existing ADJ Chat Box system messages
- Browser/PWA notification permission
- Vibration on push notifications through the service worker
- Web Push subscription storage
- A Supabase Edge Function that sends Web Push when a `notifications` row is inserted

## 1. Run the SQL

Run:

`SUPABASE_V19_2_25_BOOKING_ALERTS.sql`

in Supabase SQL Editor.

## 2. Generate VAPID keys

On a computer with Node/npm:

```bash
npx web-push generate-vapid-keys
```

Keep the private key secret.

## 3. Configure the app public key

In `customer.html`, replace the empty value of:

```js
const ADJ_VAPID_PUBLIC_KEY = '';
```

with the generated VAPID **public** key.

Never put the private key in `customer.html`.

## 4. Configure Supabase Edge Function secrets

Set these secrets for the `adj-push-notification` function:

```text
SUPABASE_URL=<your Supabase project URL>
SUPABASE_SERVICE_ROLE_KEY=<your service-role key>
VAPID_PUBLIC_KEY=<your VAPID public key>
VAPID_PRIVATE_KEY=<your VAPID private key>
VAPID_SUBJECT=mailto:<your-admin-email>
```

Deploy:

```bash
supabase functions deploy adj-push-notification
```

## 5. Create the Database Webhook

In Supabase Dashboard:

Database → Webhooks → Create webhook

Table:

`public.notifications`

Event:

`INSERT`

Destination:

Supabase Edge Function → `adj-push-notification`

Use POST and the Supabase service/auth header requested by the webhook UI.

## Result

Admin confirms a booking → the existing Admin alert flow writes one notification + one Chat Box message.

Customer receives the same message in:

1. ADJ Chat Box
2. ADJ Notifications screen
3. Phone push notification when Web Push is configured and permitted

The service worker requests a notification with vibration enabled. Actual sound behavior is controlled by Android/browser notification settings/channel.
