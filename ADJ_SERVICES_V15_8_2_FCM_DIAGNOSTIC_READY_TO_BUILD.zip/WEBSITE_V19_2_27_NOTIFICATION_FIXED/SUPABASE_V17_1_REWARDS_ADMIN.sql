-- =========================================================
-- ADJ SERVICES V17.1 — ADMIN REWARD POINTS MANAGEMENT
-- Safe/idempotent migration
-- =========================================================
BEGIN;

ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS reward_points integer NOT NULL DEFAULT 0;

ALTER TABLE public.profiles
DROP CONSTRAINT IF EXISTS profiles_reward_points_nonnegative;

ALTER TABLE public.profiles
ADD CONSTRAINT profiles_reward_points_nonnegative
CHECK (reward_points >= 0);

CREATE OR REPLACE FUNCTION public.admin_adjust_reward_points(
  p_customer_id uuid,
  p_points integer,
  p_note text DEFAULT 'Manual Admin adjustment'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_admin_role text;
  v_old integer;
  v_new integer;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Admin login required';
  END IF;

  SELECT lower(coalesce(role,'')) INTO v_admin_role
  FROM public.profiles
  WHERE id = auth.uid();

  IF v_admin_role <> 'admin' THEN
    RAISE EXCEPTION 'Admin access required';
  END IF;

  IF p_points IS NULL OR p_points = 0 THEN
    RAISE EXCEPTION 'Points change cannot be zero';
  END IF;

  SELECT reward_points INTO v_old
  FROM public.profiles
  WHERE id = p_customer_id
    AND lower(coalesce(role,'')) = 'customer'
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Customer not found';
  END IF;

  v_new := GREATEST(0, v_old + p_points);

  UPDATE public.profiles
  SET reward_points = v_new
  WHERE id = p_customer_id;

  -- Keep a lightweight audit trail when the referral-events table exists.
  BEGIN
    INSERT INTO public.adj_referral_events
      (referrer_id, referred_customer_id, booking_id, points, event_type, created_at)
    VALUES
      (auth.uid(), p_customer_id, NULL, p_points, 'admin_adjustment', now());
  EXCEPTION WHEN undefined_table OR undefined_column THEN
    NULL;
  END;

  RETURN jsonb_build_object(
    'success', true,
    'customer_id', p_customer_id,
    'old_points', v_old,
    'new_points', v_new,
    'change', p_points
  );
END;
$$;

REVOKE ALL ON FUNCTION public.admin_adjust_reward_points(uuid, integer, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_adjust_reward_points(uuid, integer, text) TO authenticated;

COMMIT;
