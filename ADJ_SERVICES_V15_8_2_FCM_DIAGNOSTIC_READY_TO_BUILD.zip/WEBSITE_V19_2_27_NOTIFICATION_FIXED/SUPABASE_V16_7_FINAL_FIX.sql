-- ADJ SERVICES V16.7 FINAL FIX
-- Customer booking flow + old booking tracking + public Welcome slideshow
-- Run this whole script once in Supabase SQL Editor.

begin;

-- 1) CUSTOMER BOOKINGS: safe read/insert permissions
alter table public.bookings enable row level security;
grant select, insert, update on public.bookings to authenticated;

drop policy if exists "ADJ V16 customer booking insert" on public.bookings;
create policy "ADJ V16 customer booking insert"
on public.bookings for insert to authenticated
with check (customer_id = auth.uid() or public.get_my_role() = 'admin');

drop policy if exists "ADJ V16 customer booking read" on public.bookings;
create policy "ADJ V16 customer booking read"
on public.bookings for select to authenticated
using (customer_id = auth.uid() or technician_id = auth.uid() or public.get_my_role() = 'admin');

-- 2) NEW BOOKINGS RPC: customer_id is always the real logged-in UID.
create or replace function public.customer_create_booking(
  p_booking_code text,
  p_service_name text,
  p_customer_name text,
  p_customer_phone text,
  p_address text,
  p_appliance text,
  p_problem text,
  p_preferred_date date,
  p_preferred_time time,
  p_estimated_price numeric default 0
)
returns public.bookings
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row public.bookings;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  insert into public.bookings (
    booking_code, customer_id, service_name, customer_name, customer_phone,
    address, appliance, problem, preferred_date, preferred_time,
    status, estimated_price
  ) values (
    p_booking_code, auth.uid(),
    coalesce(nullif(trim(p_service_name),''),'Service'),
    coalesce(nullif(trim(p_customer_name),''),'Customer'),
    coalesce(p_customer_phone,''),
    coalesce(nullif(trim(p_address),''),'Jaipur'),
    coalesce(nullif(trim(p_appliance),''),'General'),
    coalesce(nullif(trim(p_problem),''),'Not specified'),
    p_preferred_date, p_preferred_time,
    'Pending', coalesce(p_estimated_price,0)
  )
  returning * into v_row;

  return v_row;
end;
$$;

revoke all on function public.customer_create_booking(
  text,text,text,text,text,text,text,date,time,numeric
) from public;
grant execute on function public.customer_create_booking(
  text,text,text,text,text,text,text,date,time,numeric
) to authenticated;

-- 3) OLD BOOKINGS: return bookings belonging to the logged-in customer.
-- Also recovers legacy records whose customer_id is different but the
-- saved customer_phone matches the current profile phone.
create or replace function public.customer_get_bookings()
returns setof public.bookings
language plpgsql
security definer
stable
set search_path = public
as $$
declare
  v_phone text;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select nullif(trim(phone),'') into v_phone
  from public.profiles
  where id = auth.uid();

  return query
  select b.*
  from public.bookings b
  where b.customer_id = auth.uid()
     or (v_phone is not null and nullif(trim(coalesce(b.customer_phone,'')),'') = v_phone)
  order by b.created_at desc nulls last;
end;
$$;

revoke all on function public.customer_get_bookings() from public;
grant execute on function public.customer_get_bookings() to authenticated;

-- 4) WELCOME PAGE: public read access for the website settings row.
alter table public.website_settings enable row level security;
grant select on public.website_settings to anon, authenticated;

drop policy if exists "ADJ public website settings read" on public.website_settings;
create policy "ADJ public website settings read"
on public.website_settings for select to anon, authenticated
using (true);

-- 5) SERVICE CATEGORY IMAGES: customer/welcome page can read active categories.
alter table public.service_categories enable row level security;
grant select on public.service_categories to anon, authenticated;

drop policy if exists "ADJ public active service categories read" on public.service_categories;
create policy "ADJ public active service categories read"
on public.service_categories for select to anon, authenticated
using (is_active = true or public.get_my_role() = 'admin');

-- 6) STORAGE: public website images must be readable by the Welcome page.
-- This does not make chat attachments public; it only covers site-assets.
drop policy if exists "ADJ site assets public read" on storage.objects;
create policy "ADJ site assets public read"
on storage.objects for select to public
using (bucket_id = 'site-assets');

-- Make the website asset bucket public so getPublicUrl() images actually render
-- on the public Welcome/Customer pages.
update storage.buckets set public = true where id = 'site-assets';

-- Admin remains responsible for uploads/deletes through existing authenticated policies.

notify pgrst, 'reload schema';
commit;
