-- ADJ SERVICES V13.6 FIXES
-- Run once in Supabase SQL Editor. Safe to re-run.

-- Saved customer addresses may optionally store coordinates.
alter table public.customer_addresses add column if not exists latitude double precision;
alter table public.customer_addresses add column if not exists longitude double precision;

-- Booking coordinates used by Admin and Technician navigation.
alter table public.bookings add column if not exists latitude double precision;
alter table public.bookings add column if not exists longitude double precision;
alter table public.bookings add column if not exists location_accuracy double precision;

-- Chat read/delete state used by the app.
alter table public.service_chats add column if not exists delivered_at timestamptz default now();
alter table public.service_chats add column if not exists read_at timestamptz;
alter table public.service_chats add column if not exists deleted_for_everyone boolean not null default false;
alter table public.service_chats add column if not exists deleted_for_user_ids uuid[] not null default '{}';

grant select, insert, update, delete on public.service_chats to authenticated;

drop policy if exists "ADJ chat select" on public.service_chats;
drop policy if exists "ADJ chat insert" on public.service_chats;
drop policy if exists "ADJ chat update" on public.service_chats;
drop policy if exists "ADJ chat delete" on public.service_chats;

create policy "ADJ chat select" on public.service_chats for select to authenticated
using (user_id=auth.uid() or get_my_role()='admin');

create policy "ADJ chat insert" on public.service_chats for insert to authenticated
with check (sender_id=auth.uid() and (user_id=auth.uid() or get_my_role()='admin'));

create policy "ADJ chat update" on public.service_chats for update to authenticated
using (sender_id=auth.uid() or user_id=auth.uid() or get_my_role()='admin')
with check (sender_id=auth.uid() or user_id=auth.uid() or get_my_role()='admin');

create policy "ADJ chat delete" on public.service_chats for delete to authenticated
using (user_id=auth.uid() or get_my_role()='admin');

do $$ begin
  alter publication supabase_realtime add table public.service_chats;
exception when duplicate_object then null; when undefined_object then null; end $$;

-- Notifications must be delivered by the app to the other participant, not the sender.
-- The V13.6 app performs that routing client-side and suppresses notification rows
-- when the recipient is online (Realtime chat is used instead).
