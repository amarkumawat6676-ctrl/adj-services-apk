-- ADJ SERVICES V17.0 — Rating / Review safety guard
begin;

create or replace function public.adj_validate_customer_review()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  v_status text;
  v_customer uuid;
  v_existing uuid;
begin
  select lower(coalesce(status,'')), customer_id
    into v_status, v_customer
  from public.bookings
  where id = new.booking_id;

  if v_customer is null or v_customer <> new.customer_id then
    raise exception 'Review customer does not match booking';
  end if;

  if v_status not in ('completed','complete','service completed') then
    raise exception 'Only completed services can be rated';
  end if;

  if new.rating < 1 or new.rating > 5 then
    raise exception 'Rating must be between 1 and 5';
  end if;

  if tg_op = 'INSERT' then
    select id into v_existing
    from public.reviews
    where booking_id = new.booking_id
      and customer_id = new.customer_id
    limit 1;

    if v_existing is not null then
      raise exception 'This service has already been rated';
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists adj_validate_customer_review_trigger on public.reviews;
create trigger adj_validate_customer_review_trigger
before insert or update on public.reviews
for each row execute function public.adj_validate_customer_review();

notify pgrst,'reload schema';
commit;
