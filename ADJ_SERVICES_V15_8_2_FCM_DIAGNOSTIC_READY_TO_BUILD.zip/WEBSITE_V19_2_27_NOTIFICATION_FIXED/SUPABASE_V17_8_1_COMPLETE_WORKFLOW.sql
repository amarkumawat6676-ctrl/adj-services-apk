BEGIN;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS public.customer_appliances (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), customer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
 name text NOT NULL, category text, model text, serial_number text, warranty_start_date date, warranty_end_date date,
 warranty_status text, last_service_date date, next_service_date date, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(customer_id,name)
);
ALTER TABLE public.customer_appliances ENABLE ROW LEVEL SECURITY;
GRANT SELECT,INSERT,UPDATE ON public.customer_appliances TO authenticated;
DROP POLICY IF EXISTS "ADJ appliances own/admin" ON public.customer_appliances;
CREATE POLICY "ADJ appliances own/admin" ON public.customer_appliances FOR ALL TO authenticated USING (customer_id=auth.uid() OR public.get_my_role()='admin') WITH CHECK (customer_id=auth.uid() OR public.get_my_role()='admin');
CREATE TABLE IF NOT EXISTS public.service_history (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), booking_id uuid REFERENCES public.bookings(id) ON DELETE SET NULL, customer_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
 technician_id uuid, appliance text, service_name text, service_date date, service_charge numeric(12,2) DEFAULT 0, parts_charge numeric(12,2) DEFAULT 0,
 discount numeric(12,2) DEFAULT 0, reward_points_redeemed integer DEFAULT 0, reward_discount numeric(12,2) DEFAULT 0, final_amount numeric(12,2) DEFAULT 0,
 payment_status text DEFAULT 'Unpaid', payment_mode text, work_done text, parts_used text, before_photo_url text, after_photo_url text, next_service_date date, technician_notes text,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.service_history ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.service_history TO authenticated;
DROP POLICY IF EXISTS "ADJ service history own/admin" ON public.service_history;
CREATE POLICY "ADJ service history own/admin" ON public.service_history FOR SELECT TO authenticated USING (customer_id=auth.uid() OR public.get_my_role()='admin');
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS service_charge numeric(12,2) DEFAULT 0;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS parts_charge numeric(12,2) DEFAULT 0;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS reward_points_redeemed integer DEFAULT 0;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS reward_discount numeric(12,2) DEFAULT 0;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS final_amount numeric(12,2);
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS paid_amount numeric(12,2) DEFAULT 0;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS payment_status text DEFAULT 'Unpaid';
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS payment_mode text;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS next_service_date date;
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS service_charge numeric(12,2) DEFAULT 0;
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS parts_charge numeric(12,2) DEFAULT 0;
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS discount numeric(12,2) DEFAULT 0;
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS reward_points_redeemed integer DEFAULT 0;
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS reward_discount numeric(12,2) DEFAULT 0;
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS final_amount numeric(12,2) DEFAULT 0;
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS paid_amount numeric(12,2) DEFAULT 0;
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS payment_status text DEFAULT 'Unpaid';
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS payment_mode text;
ALTER TABLE public.technician_job_sheets ADD COLUMN IF NOT EXISTS next_service_date date;
NOTIFY pgrst,'reload schema';
COMMIT;
