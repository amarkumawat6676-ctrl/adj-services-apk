-- ADJ SERVICES V18.1 — MANUAL ADMIN REWARD POINTS FIX
-- Purpose: keep the existing automatic reward/referral system untouched,
-- while giving Admin a separate, unambiguous RPC for manual Add/Deduct.
-- Safe to run even if the older overloaded admin_adjust_reward_points()
-- functions already exist.

BEGIN;

ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS reward_points integer NOT NULL DEFAULT 0;

ALTER TABLE public.profiles
DROP CONSTRAINT IF EXISTS profiles_reward_points_nonnegative;

ALTER TABLE public.profiles
ADD CONSTRAINT profiles_reward_points_nonnegative
CHECK (reward_points >= 0);

CREATE TABLE IF NOT EXISTS public.adj_reward_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  points integer NOT NULL,
  event_type text NOT NULL,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS adj_reward_ledger_customer_idx
ON public.adj_reward_ledger(customer_id, created_at DESC);

ALTER TABLE public.adj_reward_ledger ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.adj_reward_ledger TO authenticated;

DROP POLICY IF EXISTS "ADJ reward ledger own/admin" ON public.adj_reward_ledger;
CREATE POLICY "ADJ reward ledger own/admin"
ON public.adj_reward_ledger
FOR SELECT TO authenticated
USING (
  customer_id = auth.uid()
  OR public.get_my_role() = 'admin'
);

-- IMPORTANT: use a new function name so old overloaded RPC signatures
-- cannot cause a "best candidate function" ambiguity.
CREATE OR REPLACE FUNCTION public.admin_adjust_reward_points_manual(
  p_customer_id uuid,
  p_points integer,
  p_note text DEFAULT 'Manual Admin adjustment'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
  v_old integer;
  v_new integer;
  v_name text;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Admin login required';
  END IF;

  SELECT lower(coalesce(role,''))
    INTO v_role
  FROM public.profiles
  WHERE id = auth.uid();

  IF v_role <> 'admin' THEN
    RAISE EXCEPTION 'Only Admin can change reward points';
  END IF;

  IF coalesce(p_points, 0) = 0 THEN
    RAISE EXCEPTION 'Points change cannot be zero';
  END IF;

  SELECT full_name, coalesce(reward_points, 0)
    INTO v_name, v_old
  FROM public.profiles
  WHERE id = p_customer_id
    AND lower(coalesce(role,'')) = 'customer'
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Customer account not found';
  END IF;

  v_new := v_old + p_points;

  IF v_new < 0 THEN
    RAISE EXCEPTION 'Customer does not have enough points. Current balance: %', v_old;
  END IF;

  -- Manual adjustment only. Existing automatic reward triggers/functions
  -- are not modified by this function.
  UPDATE public.profiles
  SET reward_points = v_new
  WHERE id = p_customer_id;

  INSERT INTO public.adj_reward_ledger(customer_id, points, event_type, note)
  VALUES (
    p_customer_id,
    p_points,
    CASE WHEN p_points > 0 THEN 'admin_points_added' ELSE 'admin_points_deducted' END,
    coalesce(nullif(trim(p_note),''), 'Manual Admin adjustment')
  );

  RETURN jsonb_build_object(
    'success', true,
    'customer_id', p_customer_id,
    'customer_name', v_name,
    'old_points', v_old,
    'changed_points', p_points,
    'new_points', v_new,
    'note', coalesce(p_note, '')
  );
END;
$$;

REVOKE ALL ON FUNCTION public.admin_adjust_reward_points_manual(uuid, integer, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_adjust_reward_points_manual(uuid, integer, text) TO authenticated;

NOTIFY pgrst, 'reload schema';

COMMIT;
