-- ADJ SERVICES V17.8 - Reward redemption + technician final billing safety
-- Safe to run after the existing ADJ SERVICES SQL. Existing columns are preserved.

alter table public.bookings add column if not exists reward_points_redeemed integer not null default 0;
alter table public.bookings add column if not exists reward_discount numeric not null default 0;
alter table public.bookings add column if not exists service_charge numeric not null default 0;
alter table public.bookings add column if not exists parts_charge numeric not null default 0;
alter table public.bookings add column if not exists discount numeric not null default 0;
alter table public.bookings add column if not exists final_amount numeric not null default 0;
alter table public.bookings add column if not exists final_price numeric not null default 0;
alter table public.bookings add column if not exists paid_amount numeric not null default 0;
alter table public.bookings add column if not exists payment_status text not null default 'Unpaid';
alter table public.bookings add column if not exists payment_mode text;

alter table public.technician_job_sheets add column if not exists reward_points_redeemed integer not null default 0;
alter table public.technician_job_sheets add column if not exists reward_discount numeric not null default 0;
alter table public.technician_job_sheets add column if not exists service_charge numeric not null default 0;
alter table public.technician_job_sheets add column if not exists parts_charge numeric not null default 0;
alter table public.technician_job_sheets add column if not exists discount numeric not null default 0;
alter table public.technician_job_sheets add column if not exists final_amount numeric not null default 0;
alter table public.technician_job_sheets add column if not exists paid_amount numeric not null default 0;
alter table public.technician_job_sheets add column if not exists payment_status text not null default 'Unpaid';
alter table public.technician_job_sheets add column if not exists payment_mode text;
alter table public.technician_job_sheets add column if not exists next_service_date date;

-- Keep old bookings consistent where a reward discount was already recorded.
update public.bookings
set final_amount = greatest(0, coalesce(service_charge, estimated_price, 0) + coalesce(parts_charge,0) - coalesce(discount,0))
where coalesce(final_amount,0)=0
  and (coalesce(service_charge,0)<>0 or coalesce(parts_charge,0)<>0 or coalesce(discount,0)<>0);

-- Keep job-sheet totals mathematically consistent for existing rows.
update public.technician_job_sheets
set final_amount = greatest(0, coalesce(service_charge,0) + coalesce(parts_charge,0) - coalesce(discount,0))
where coalesce(final_amount,0)=0
  and (coalesce(service_charge,0)<>0 or coalesce(parts_charge,0)<>0 or coalesce(discount,0)<>0);
