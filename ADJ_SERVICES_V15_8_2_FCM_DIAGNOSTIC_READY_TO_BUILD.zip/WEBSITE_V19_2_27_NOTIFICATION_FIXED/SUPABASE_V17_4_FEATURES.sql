-- ADJ SERVICES V17.4 FEATURE PACK
-- Features:
-- 1) Admin reward points RPC
-- 2) Service subcategories (e.g. AC -> Split/Window/Cassette/Central)
-- 3) Customer upcoming services managed by Admin
-- 4) Safe RLS + PostgREST reload

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- =========================================================
-- 1. ADMIN REWARD POINTS ADJUSTMENT
-- =========================================================
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS reward_points integer NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS public.adj_referral_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  referred_customer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES public.bookings(id) ON DELETE SET NULL,
  event_type text NOT NULL DEFAULT 'completed_service',
  points integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.adj_referral_events ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.adj_referral_events TO authenticated;
DROP POLICY IF EXISTS "ADJ referral events own/admin" ON public.adj_referral_events;
CREATE POLICY "ADJ referral events own/admin" ON public.adj_referral_events FOR SELECT TO authenticated
USING (referrer_id=auth.uid() OR referred_customer_id=auth.uid() OR public.get_my_role()='admin');

CREATE OR REPLACE FUNCTION public.admin_adjust_reward_points(
  p_customer_id uuid,
  p_points integer,
  p_note text DEFAULT 'Manual Admin adjustment'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
DECLARE
  v_role text;
  v_old integer;
  v_new integer;
  v_name text;
BEGIN
  SELECT lower(coalesce(role,'')) INTO v_role
  FROM public.profiles WHERE id=auth.uid();
  IF v_role <> 'admin' THEN RAISE EXCEPTION 'Only Admin can change reward points'; END IF;

  SELECT full_name, coalesce(reward_points,0)
    INTO v_name, v_old
  FROM public.profiles
  WHERE id=p_customer_id AND lower(coalesce(role,''))='customer'
  FOR UPDATE;

  IF NOT FOUND THEN RAISE EXCEPTION 'Customer account not found'; END IF;
  IF coalesce(p_points,0)=0 THEN RAISE EXCEPTION 'Points cannot be zero'; END IF;

  v_new := v_old + p_points;
  IF v_new < 0 THEN
    RAISE EXCEPTION 'Customer does not have enough points. Current balance: %', v_old;
  END IF;

  UPDATE public.profiles
  SET reward_points=v_new, updated_at=now()
  WHERE id=p_customer_id;

  -- Reuse the existing reward event ledger. Admin adjustments are deliberately
  -- booking-independent and therefore keep booking_id NULL.
  INSERT INTO public.adj_referral_events(
    referrer_id,referred_customer_id,booking_id,event_type,points
  ) VALUES(
    auth.uid(),p_customer_id,NULL,
    CASE WHEN p_points>0 THEN 'admin_points_added' ELSE 'admin_points_deducted' END,
    p_points
  );

  RETURN jsonb_build_object(
    'success',true,
    'customer_id',p_customer_id,
    'customer_name',v_name,
    'old_points',v_old,
    'changed_points',p_points,
    'new_points',v_new,
    'note',coalesce(p_note,'')
  );
END;
$$;

REVOKE ALL ON FUNCTION public.admin_adjust_reward_points(uuid,integer,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_adjust_reward_points(uuid,integer,text) TO authenticated;

-- Keep compatibility with the frontend argument order currently used.
-- This wrapper accepts (customer, note, points).
CREATE OR REPLACE FUNCTION public.admin_adjust_reward_points(
  p_customer_id uuid,
  p_note text,
  p_points integer
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
BEGIN
  RETURN public.admin_adjust_reward_points(p_customer_id,p_points,p_note);
END;
$$;
REVOKE ALL ON FUNCTION public.admin_adjust_reward_points(uuid,text,integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_adjust_reward_points(uuid,text,integer) TO authenticated;

-- =========================================================
-- 2. SERVICE SUBCATEGORIES
-- =========================================================
CREATE TABLE IF NOT EXISTS public.service_subcategories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid NOT NULL REFERENCES public.service_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  icon text,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS service_subcategories_category_idx
  ON public.service_subcategories(category_id,is_active,sort_order,name);

-- Seed the standard appliance types only when the matching category exists.
DO $$
DECLARE c uuid;
BEGIN
  SELECT id INTO c FROM public.service_categories WHERE lower(name) IN ('air conditioner','ac','ac repair') ORDER BY sort_order LIMIT 1;
  IF c IS NOT NULL THEN
    INSERT INTO public.service_subcategories(category_id,name,sort_order)
    SELECT c,v,ord FROM (VALUES ('Split AC',1),('Window AC',2),('Cassette AC',3),('Central AC',4)) x(v,ord)
    WHERE NOT EXISTS (SELECT 1 FROM public.service_subcategories s WHERE s.category_id=c AND lower(s.name)=lower(v));
  END IF;

  SELECT id INTO c FROM public.service_categories WHERE lower(name) LIKE '%refrigerator%' ORDER BY sort_order LIMIT 1;
  IF c IS NOT NULL THEN
    INSERT INTO public.service_subcategories(category_id,name,sort_order)
    SELECT c,v,ord FROM (VALUES ('Single Door',1),('Double Door',2),('Side by Side',3),('Deep Freezer',4)) x(v,ord)
    WHERE NOT EXISTS (SELECT 1 FROM public.service_subcategories s WHERE s.category_id=c AND lower(s.name)=lower(v));
  END IF;

  SELECT id INTO c FROM public.service_categories WHERE lower(name) LIKE '%washing machine%' ORDER BY sort_order LIMIT 1;
  IF c IS NOT NULL THEN
    INSERT INTO public.service_subcategories(category_id,name,sort_order)
    SELECT c,v,ord FROM (VALUES ('Top Load',1),('Front Load',2),('Semi-Automatic',3)) x(v,ord)
    WHERE NOT EXISTS (SELECT 1 FROM public.service_subcategories s WHERE s.category_id=c AND lower(s.name)=lower(v));
  END IF;
END $$;

ALTER TABLE public.services
  ADD COLUMN IF NOT EXISTS subcategory_id uuid;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname='services_subcategory_id_fkey'
  ) THEN
    ALTER TABLE public.services
      ADD CONSTRAINT services_subcategory_id_fkey
      FOREIGN KEY (subcategory_id)
      REFERENCES public.service_subcategories(id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS services_subcategory_idx
  ON public.services(subcategory_id);

ALTER TABLE public.service_subcategories ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.service_subcategories TO anon,authenticated;
GRANT INSERT,UPDATE,DELETE ON public.service_subcategories TO authenticated;

DROP POLICY IF EXISTS "ADJ subcategories public active read" ON public.service_subcategories;
CREATE POLICY "ADJ subcategories public active read"
ON public.service_subcategories FOR SELECT
TO anon,authenticated
USING (is_active=true OR public.get_my_role()='admin');

DROP POLICY IF EXISTS "ADJ subcategories admin write" ON public.service_subcategories;
CREATE POLICY "ADJ subcategories admin write"
ON public.service_subcategories FOR ALL
TO authenticated
USING (public.get_my_role()='admin')
WITH CHECK (public.get_my_role()='admin');

-- =========================================================
-- 3. UPCOMING SERVICES CONTROLLED FROM ADMIN
-- =========================================================
CREATE TABLE IF NOT EXISTS public.upcoming_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  service_date date,
  service_time text,
  badge text DEFAULT 'Coming Soon',
  image_url text,
  booking_service_id uuid REFERENCES public.services(id) ON DELETE SET NULL,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS upcoming_services_active_idx
  ON public.upcoming_services(is_active,sort_order,service_date);

ALTER TABLE public.upcoming_services ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.upcoming_services TO anon,authenticated;
GRANT INSERT,UPDATE,DELETE ON public.upcoming_services TO authenticated;

DROP POLICY IF EXISTS "ADJ upcoming public active read" ON public.upcoming_services;
CREATE POLICY "ADJ upcoming public active read"
ON public.upcoming_services FOR SELECT
TO anon,authenticated
USING (is_active=true OR public.get_my_role()='admin');

DROP POLICY IF EXISTS "ADJ upcoming admin write" ON public.upcoming_services;
CREATE POLICY "ADJ upcoming admin write"
ON public.upcoming_services FOR ALL
TO authenticated
USING (public.get_my_role()='admin')
WITH CHECK (public.get_my_role()='admin');

NOTIFY pgrst,'reload schema';
COMMIT;
