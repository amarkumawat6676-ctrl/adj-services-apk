-- =========================================================
-- ADJ SERVICES V17.7
-- PROFILE EMAIL / BOOKING REWARD REDEMPTION / FINAL BILL
-- SERVICE DATE / SERVICE PIN HARDENING
-- =========================================================

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- =========================================================
-- 1. BOOKING REWARD COLUMNS
-- =========================================================
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS reward_points_redeemed integer NOT NULL DEFAULT 0;

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS reward_discount numeric(12,2) NOT NULL DEFAULT 0;

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS final_amount numeric(12,2);

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS service_id uuid;

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS subcategory_id uuid;

-- Final amount defaults to the normal estimated price for old/new bookings.
UPDATE public.bookings
SET final_amount = COALESCE(final_amount, estimated_price, 0)
WHERE final_amount IS NULL;

-- =========================================================
-- 2. CUSTOMER REDEEM POINTS
-- =========================================================
CREATE OR REPLACE FUNCTION public.customer_redeem_points(
  p_booking_id uuid,
  p_points integer
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me uuid := auth.uid();
  v_balance integer;
  v_price numeric(12,2);
  v_rate numeric(12,2);
  v_max integer;
  v_points integer;
  v_discount numeric(12,2);
  v_final numeric(12,2);
  v_old_redeemed integer;
BEGIN
  IF me IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;

  IF COALESCE(p_points,0) <= 0 THEN
    RAISE EXCEPTION 'Enter a valid number of reward points';
  END IF;

  SELECT
    COALESCE(reward_points,0)
  INTO v_balance
  FROM public.profiles
  WHERE id = me
    AND lower(coalesce(role,'')) = 'customer'
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Customer account not found';
  END IF;

  SELECT
    COALESCE(estimated_price,0),
    COALESCE(reward_points_redeemed,0)
  INTO
    v_price,
    v_old_redeemed
  FROM public.bookings
  WHERE id = p_booking_id
    AND customer_id = me
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Booking not found';
  END IF;

  IF v_old_redeemed > 0 THEN
    RAISE EXCEPTION 'Reward points have already been redeemed for this booking';
  END IF;

  SELECT
    COALESCE(rupees_per_point,1),
    COALESCE(max_points_per_booking,100)
  INTO
    v_rate,
    v_max
  FROM public.adj_referral_settings
  WHERE id = 1;

  v_rate := COALESCE(v_rate,1);
  v_max := COALESCE(v_max,100);

  IF p_points > v_balance THEN
    RAISE EXCEPTION 'You only have % reward points available', v_balance;
  END IF;

  v_points := LEAST(p_points,v_max);
  v_discount := LEAST(v_price, v_points * v_rate);
  v_final := GREATEST(0, v_price - v_discount);

  UPDATE public.profiles
  SET reward_points = reward_points - v_points,
      updated_at = now()
  WHERE id = me;

  UPDATE public.bookings
  SET reward_points_redeemed = v_points,
      reward_discount = v_discount,
      final_amount = v_final,
      updated_at = now()
  WHERE id = p_booking_id
    AND customer_id = me;

  INSERT INTO public.adj_reward_ledger
  (
    customer_id,
    points,
    event_type,
    note
  )
  VALUES
  (
    me,
    -v_points,
    'booking_redemption',
    'Reward points redeemed on booking ' || p_booking_id::text
  );

  RETURN jsonb_build_object(
    'success',true,
    'booking_id',p_booking_id,
    'points_redeemed',v_points,
    'discount',v_discount,
    'final_amount',v_final,
    'remaining_points',v_balance-v_points
  );
END;
$$;

REVOKE ALL
ON FUNCTION public.customer_redeem_points(uuid,integer)
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.customer_redeem_points(uuid,integer)
TO authenticated;

-- =========================================================
-- 3. SERVICE DATE VALIDATION
-- =========================================================
CREATE OR REPLACE FUNCTION public.adj_validate_booking_pin(
  p_pincode text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT regexp_like(trim(coalesce(p_pincode,'')), '^[0-9]{6}$') THEN
    RETURN false;
  END IF;

  RETURN EXISTS (
    SELECT 1
    FROM public.service_areas
    WHERE is_active = true
      AND trim(p_pincode) = ANY(pincodes)
  );
END;
$$;

REVOKE ALL
ON FUNCTION public.adj_validate_booking_pin(text)
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.adj_validate_booking_pin(text)
TO anon, authenticated;

-- =========================================================
-- 4. PROFILE EMAIL SUPPORT
-- Customer can keep name/mobile/address locked in UI.
-- Email is the editable contact field.
-- =========================================================
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS email text;

-- =========================================================
-- 5. REWARD SETTINGS SAFETY
-- =========================================================
CREATE TABLE IF NOT EXISTS public.adj_referral_settings (
  id integer PRIMARY KEY,
  enabled boolean NOT NULL DEFAULT true,
  signup_bonus_points integer NOT NULL DEFAULT 100,
  points_per_completed_service integer NOT NULL DEFAULT 100,
  rupees_per_point numeric(10,2) NOT NULL DEFAULT 1,
  max_points_per_booking integer NOT NULL DEFAULT 100,
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.adj_referral_settings
(
  id,
  enabled,
  signup_bonus_points,
  points_per_completed_service,
  rupees_per_point,
  max_points_per_booking
)
VALUES
(
  1,
  true,
  100,
  100,
  1,
  100
)
ON CONFLICT(id) DO NOTHING;

-- =========================================================
-- 6. SERVICE AREAS
-- Preserve admin-controlled PIN list.
-- =========================================================
CREATE TABLE IF NOT EXISTS public.service_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  state text,
  city text,
  area_name text,
  pincodes text[] NOT NULL DEFAULT '{}',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS service_areas_pincodes_gin_idx
ON public.service_areas USING gin(pincodes);

-- =========================================================
-- 7. RELOAD API SCHEMA CACHE
-- =========================================================
NOTIFY pgrst, 'reload schema';

COMMIT;

-- =========================================================
-- V17.7 COMPLETE
-- =========================================================


-- =========================================================
-- 8. PROFILE EMAIL / AUTH COMPATIBILITY
-- =========================================================
-- The customer UI keeps mobile number immutable but allows a real email.
-- Mobile login continues to work after the auth email is changed because
-- the frontend resolves the profile email first.

-- =========================================================
-- 9. JOB SHEET REWARD BILL SUPPORT
-- =========================================================
ALTER TABLE public.technician_job_sheets
  ADD COLUMN IF NOT EXISTS reward_points_redeemed integer NOT NULL DEFAULT 0;

ALTER TABLE public.technician_job_sheets
  ADD COLUMN IF NOT EXISTS reward_discount numeric(12,2) NOT NULL DEFAULT 0;

NOTIFY pgrst,'reload schema';
