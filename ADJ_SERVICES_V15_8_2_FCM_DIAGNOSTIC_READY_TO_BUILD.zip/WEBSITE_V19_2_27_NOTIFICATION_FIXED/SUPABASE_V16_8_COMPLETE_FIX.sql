-- ADJ SERVICES V16.8 COMPLETE FIX
-- Run this whole script once in Supabase SQL Editor.
-- Safe to re-run. Does not delete existing customer/booking data.

begin;

-- ============================================================
-- 1) MULTIPLE SAVED CUSTOMER ADDRESSES
-- ============================================================
create table if not exists public.adj_customer_addresses (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id) on delete cascade,
  label text not null default 'Home',
  address text not null,
  latitude double precision,
  longitude double precision,
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists adj_customer_addresses_customer_idx
on public.adj_customer_addresses(customer_id, created_at);

alter table public.adj_customer_addresses enable row level security;
grant select, insert, update, delete on public.adj_customer_addresses to authenticated;

drop policy if exists "ADJ saved addresses select own" on public.adj_customer_addresses;
create policy "ADJ saved addresses select own"
on public.adj_customer_addresses for select to authenticated
using (customer_id = auth.uid());

drop policy if exists "ADJ saved addresses insert own" on public.adj_customer_addresses;
create policy "ADJ saved addresses insert own"
on public.adj_customer_addresses for insert to authenticated
with check (customer_id = auth.uid());

drop policy if exists "ADJ saved addresses update own" on public.adj_customer_addresses;
create policy "ADJ saved addresses update own"
on public.adj_customer_addresses for update to authenticated
using (customer_id = auth.uid()) with check (customer_id = auth.uid());

drop policy if exists "ADJ saved addresses delete own" on public.adj_customer_addresses;
create policy "ADJ saved addresses delete own"
on public.adj_customer_addresses for delete to authenticated
using (customer_id = auth.uid());

-- ============================================================
-- 2) BOOKING LOCATION FIELDS
-- ============================================================
alter table public.bookings add column if not exists latitude double precision;
alter table public.bookings add column if not exists longitude double precision;
alter table public.bookings add column if not exists location_accuracy double precision;

-- ============================================================
-- 3) CHAT DELIVERY / READ RECEIPTS
-- One tick = saved/delivered. Two RED ticks = recipient has opened/read it.
-- ============================================================
alter table public.service_chats add column if not exists delivered_at timestamptz default now();
alter table public.service_chats add column if not exists read_at timestamptz;

grant select, insert, update, delete on public.service_chats to authenticated;

drop policy if exists "ADJ chat select" on public.service_chats;
create policy "ADJ chat select" on public.service_chats
for select to authenticated
using (user_id = auth.uid() or public.get_my_role() = 'admin');

drop policy if exists "ADJ chat insert" on public.service_chats;
create policy "ADJ chat insert" on public.service_chats
for insert to authenticated
with check (sender_id = auth.uid() and (user_id = auth.uid() or public.get_my_role() = 'admin'));

drop policy if exists "ADJ chat update" on public.service_chats;
create policy "ADJ chat update" on public.service_chats
for update to authenticated
using (sender_id = auth.uid() or user_id = auth.uid() or public.get_my_role() = 'admin')
with check (sender_id = auth.uid() or user_id = auth.uid() or public.get_my_role() = 'admin');

drop policy if exists "ADJ chat delete" on public.service_chats;
create policy "ADJ chat delete" on public.service_chats
for delete to authenticated
using (user_id = auth.uid() or public.get_my_role() = 'admin');

update public.service_chats set delivered_at = coalesce(delivered_at, created_at) where delivered_at is null;

-- ============================================================
-- 4) CUSTOMER BOOKING RPC WITH LOCATION SUPPORT
-- ============================================================
create or replace function public.customer_create_booking_v168(
  p_booking_code text,
  p_service_name text,
  p_customer_name text,
  p_customer_phone text,
  p_address text,
  p_appliance text,
  p_problem text,
  p_preferred_date date,
  p_preferred_time time,
  p_estimated_price numeric default 0,
  p_latitude double precision default null,
  p_longitude double precision default null,
  p_location_accuracy double precision default null
)
returns public.bookings
language plpgsql
security definer
set search_path = public
as $$
declare v_row public.bookings;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  insert into public.bookings(
    booking_code,customer_id,service_name,customer_name,customer_phone,address,
    appliance,problem,preferred_date,preferred_time,status,estimated_price,
    latitude,longitude,location_accuracy
  ) values (
    p_booking_code,auth.uid(),coalesce(nullif(trim(p_service_name),''),'Service'),
    coalesce(nullif(trim(p_customer_name),''),'Customer'),coalesce(p_customer_phone,''),
    coalesce(nullif(trim(p_address),''),'Jaipur'),coalesce(nullif(trim(p_appliance),''),'General'),
    coalesce(nullif(trim(p_problem),''),'Not specified'),p_preferred_date,p_preferred_time,
    'Pending',coalesce(p_estimated_price,0),p_latitude,p_longitude,p_location_accuracy
  ) returning * into v_row;
  return v_row;
end;
$$;

grant execute on function public.customer_create_booking_v168(text,text,text,text,text,text,text,date,time,numeric,double precision,double precision,double precision) to authenticated;

notify pgrst, 'reload schema';
commit;
