ADJ SERVICES V19.2.26 — BOOKING ALERT + EXISTING CHAT BOX

Admin status updates now create one secure customer alert that is saved in BOTH the Notifications table and the existing service_chats Chat Box.

Confirmed:
Booking Confirmed
Your service booking #ADJ123 has been confirmed. Technician details will be shared soon.

Other alerts:
Technician Assigned
Technician On The Way
Work Started
Service Completed

Customer app listens in realtime and refreshes Notifications + Chat automatically. Foreground alerts use vibration and a best-effort alert tone.

Background phone push requires Web Push/VAPID configuration and the included Edge Function. Android/browser notification sound is controlled by the device notification settings.

Run SUPABASE_V19_2_25_BOOKING_ALERTS.sql once if it has not already been run.
