-- ADJ SERVICES V14 Chat Attachments + Secure Delete
-- Run this ONCE in Supabase SQL Editor after your existing ADJ chat SQL.
-- No booking/location tables are changed by this file.

begin;

-- Message attachment metadata.
alter table public.service_chats add column if not exists attachment_path text;
alter table public.service_chats add column if not exists attachment_name text;
alter table public.service_chats add column if not exists attachment_type text;
alter table public.service_chats add column if not exists attachment_size bigint;

-- Keep the existing read/deletion columns if an older chat patch was not run.
alter table public.service_chats add column if not exists delivered_at timestamptz default now();
alter table public.service_chats add column if not exists read_at timestamptz;
alter table public.service_chats add column if not exists deleted_for_everyone boolean not null default false;
alter table public.service_chats add column if not exists deleted_for_user_ids uuid[] not null default '{}';

grant select, insert, update on public.service_chats to authenticated;

-- Private bucket: only authenticated app users can access chat attachments.
insert into storage.buckets (id, name, public)
values ('chat-attachments', 'chat-attachments', false)
on conflict (id) do update set public=false;

-- Storage policies.
drop policy if exists "ADJ chat files read" on storage.objects;
drop policy if exists "ADJ chat files upload" on storage.objects;
drop policy if exists "ADJ chat files delete" on storage.objects;

create policy "ADJ chat files read"
on storage.objects for select to authenticated
using (bucket_id = 'chat-attachments');

create policy "ADJ chat files upload"
on storage.objects for insert to authenticated
with check (bucket_id = 'chat-attachments');

create policy "ADJ chat files delete"
on storage.objects for delete to authenticated
using (bucket_id = 'chat-attachments');

-- Secure message deletion functions.
-- Delete for me: hides the message only for the current viewer.
create or replace function public.chat_delete_for_me(p_message_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_ids uuid[];
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  select deleted_for_user_ids into v_ids
  from public.service_chats
  where id = p_message_id;
  if not found then raise exception 'Message not found'; end if;
  v_ids := coalesce(v_ids, '{}'::uuid[]);
  if not (auth.uid() = any(v_ids)) then
    v_ids := array_append(v_ids, auth.uid());
  end if;
  update public.service_chats set deleted_for_user_ids=v_ids where id=p_message_id;
  return true;
end;
$$;

-- Delete for everyone: sender or admin only.
create or replace function public.chat_delete_for_everyone(p_message_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_sender uuid;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  select sender_id into v_sender from public.service_chats where id=p_message_id;
  if not found then raise exception 'Message not found'; end if;
  if v_sender <> auth.uid() and public.get_my_role() <> 'admin' then
    raise exception 'You can only delete your own message for everyone';
  end if;
  update public.service_chats set deleted_for_everyone=true where id=p_message_id;
  return true;
end;
$$;

-- Delete my entire chat view without deleting the other person's copy.
create or replace function public.chat_delete_my_chat()
returns boolean
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  update public.service_chats
  set deleted_for_user_ids = case
    when auth.uid() = any(coalesce(deleted_for_user_ids,'{}'::uuid[])) then coalesce(deleted_for_user_ids,'{}'::uuid[])
    else array_append(coalesce(deleted_for_user_ids,'{}'::uuid[]), auth.uid())
  end
  where user_id=auth.uid();
  return true;
end;
$$;

grant execute on function public.chat_delete_for_me(uuid) to authenticated;
grant execute on function public.chat_delete_for_everyone(uuid) to authenticated;
grant execute on function public.chat_delete_my_chat() to authenticated;

notify pgrst, 'reload schema';
commit;
