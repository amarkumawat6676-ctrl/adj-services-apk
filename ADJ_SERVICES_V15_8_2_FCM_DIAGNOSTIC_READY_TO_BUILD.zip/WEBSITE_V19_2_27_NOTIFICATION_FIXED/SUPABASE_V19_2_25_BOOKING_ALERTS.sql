-- ADJ SERVICES V19.2.25
-- Booking Alerts + Existing Chat Box + Web Push subscription storage
-- Safe additive migration. No customer/booking data deletion.

BEGIN;

-- ============================================================
-- 1. Push subscription storage
-- ============================================================
CREATE TABLE IF NOT EXISTS public.push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  endpoint text NOT NULL UNIQUE,
  p256dh text NOT NULL,
  auth text NOT NULL,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS push_subscriptions_user_idx
  ON public.push_subscriptions(user_id);

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE
  ON public.push_subscriptions TO authenticated;

DROP POLICY IF EXISTS "ADJ push own select" ON public.push_subscriptions;
DROP POLICY IF EXISTS "ADJ push own insert" ON public.push_subscriptions;
DROP POLICY IF EXISTS "ADJ push own update" ON public.push_subscriptions;
DROP POLICY IF EXISTS "ADJ push own delete" ON public.push_subscriptions;

CREATE POLICY "ADJ push own select"
ON public.push_subscriptions
FOR SELECT TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "ADJ push own insert"
ON public.push_subscriptions
FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "ADJ push own update"
ON public.push_subscriptions
FOR UPDATE TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "ADJ push own delete"
ON public.push_subscriptions
FOR DELETE TO authenticated
USING (user_id = auth.uid());

-- ============================================================
-- 2. Make notification rows realtime-capable
-- ============================================================
DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
EXCEPTION
  WHEN duplicate_object THEN NULL;
  WHEN undefined_object THEN NULL;
END $$;

-- Existing service_chats is already made realtime-capable by the
-- existing ADJ chat SQL. Keep this idempotent as well.
DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.service_chats;
EXCEPTION
  WHEN duplicate_object THEN NULL;
  WHEN undefined_object THEN NULL;
END $$;

-- ============================================================
-- 3. Single secure Admin -> Customer alert function
--    One call creates BOTH:
--      a) notification row
--      b) permanent Chat Box system message
-- ============================================================
CREATE OR REPLACE FUNCTION public.adj_send_customer_alert(
  p_customer_id uuid,
  p_booking_id uuid,
  p_title text,
  p_message text,
  p_type text DEFAULT 'booking_status'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me uuid := auth.uid();
  v_role text;
  v_chat_id uuid;
  v_notification_id uuid;
BEGIN
  IF me IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;

  SELECT lower(coalesce(role,''))
  INTO v_role
  FROM public.profiles
  WHERE id = me;

  IF v_role <> 'admin' THEN
    RAISE EXCEPTION 'Only Admin can send booking alerts';
  END IF;

  IF p_customer_id IS NULL THEN
    RAISE EXCEPTION 'Customer is required';
  END IF;

  INSERT INTO public.notifications
  (
    user_id,
    booking_id,
    title,
    message,
    type,
    is_read
  )
  VALUES
  (
    p_customer_id,
    p_booking_id,
    coalesce(nullif(trim(p_title),''),'ADJ SERVICES'),
    coalesce(nullif(trim(p_message),''),'You have a new update from ADJ SERVICES.'),
    coalesce(nullif(trim(p_type),''),'booking_status'),
    false
  )
  RETURNING id INTO v_notification_id;

  INSERT INTO public.service_chats
  (
    user_id,
    sender_id,
    sender_role,
    message,
    delivered_at
  )
  VALUES
  (
    p_customer_id,
    me,
    'admin',
    coalesce(nullif(trim(p_message),''),'You have a new update from ADJ SERVICES.'),
    now()
  )
  RETURNING id INTO v_chat_id;

  RETURN jsonb_build_object(
    'success', true,
    'notification_id', v_notification_id,
    'chat_id', v_chat_id
  );
END;
$$;

REVOKE ALL
ON FUNCTION public.adj_send_customer_alert(uuid,uuid,text,text,text)
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.adj_send_customer_alert(uuid,uuid,text,text,text)
TO authenticated;

-- ============================================================
-- 4. Helpful updated_at trigger for push subscriptions
-- ============================================================
CREATE OR REPLACE FUNCTION public.adj_push_subscription_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_adj_push_subscription_updated
ON public.push_subscriptions;

CREATE TRIGGER trg_adj_push_subscription_updated
BEFORE UPDATE ON public.push_subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.adj_push_subscription_updated_at();

NOTIFY pgrst, 'reload schema';

COMMIT;
