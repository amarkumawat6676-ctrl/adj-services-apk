-- ADJ SERVICES V17.0 final DB guardrails
begin;

-- Customer may review only a completed booking, and only once per booking.
drop index if exists public.adj_reviews_booking_customer_unique;
create unique index if not exists adj_reviews_booking_customer_unique
on public.reviews(booking_id, customer_id);

create or replace function public.adj_validate_customer_review()
returns trigger language plpgsql security definer set search_path=public as $$
declare v_status text; v_customer uuid;
begin
  select lower(coalesce(status,'')), customer_id into v_status,v_customer from public.bookings where id=NEW.booking_id;
  if v_customer is null or v_customer <> NEW.customer_id then raise exception 'Review customer does not match booking'; end if;
  if v_status not in ('completed','complete','service completed') then raise exception 'Only completed services can be rated'; end if;
  if NEW.rating < 1 or NEW.rating > 5 then raise exception 'Rating must be between 1 and 5'; end if;
  return NEW;
end; $$;

drop trigger if exists adj_validate_customer_review_trigger on public.reviews;
create trigger adj_validate_customer_review_trigger before insert or update on public.reviews for each row execute function public.adj_validate_customer_review();

notify pgrst,'reload schema';
commit;
