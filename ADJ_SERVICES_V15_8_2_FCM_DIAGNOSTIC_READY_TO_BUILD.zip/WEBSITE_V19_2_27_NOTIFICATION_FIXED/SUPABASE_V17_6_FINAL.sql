-- =========================================================
-- ADJ SERVICES V17.6 FINAL LOCATION + REWARDS SAFETY SQL
-- =========================================================
-- 1) Admin-defined PIN-code service areas
-- 2) Strict customer booking validation by PIN
-- 3) Automatic 100-point signup bonus (configurable)
-- 4) Automatic referral reward after referred booking is completed
-- 5) Admin reward add/deduct RPC
-- 6) Referral code + referred_by support
-- 7) Reward ledger
-- =========================================================

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------
-- REWARD BALANCE
-- ---------------------------------------------------------
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS reward_points integer NOT NULL DEFAULT 0;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS referral_code text;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS referred_by uuid;

-- Self-reference is added only when the column is new/usable.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname='profiles_referred_by_fkey'
      AND conrelid='public.profiles'::regclass
  ) THEN
    BEGIN
      ALTER TABLE public.profiles
        ADD CONSTRAINT profiles_referred_by_fkey
        FOREIGN KEY (referred_by) REFERENCES public.profiles(id)
        ON DELETE SET NULL;
    EXCEPTION WHEN duplicate_object THEN NULL;
    END;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS profiles_referral_code_idx
  ON public.profiles(referral_code);

-- ---------------------------------------------------------
-- REFERRAL SETTINGS
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.adj_referral_settings (
  id integer PRIMARY KEY,
  enabled boolean NOT NULL DEFAULT true,
  signup_bonus_points integer NOT NULL DEFAULT 100,
  points_per_completed_service integer NOT NULL DEFAULT 100,
  rupees_per_point numeric(10,2) NOT NULL DEFAULT 1,
  max_points_per_booking integer NOT NULL DEFAULT 100,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.adj_referral_settings
  ADD COLUMN IF NOT EXISTS signup_bonus_points integer NOT NULL DEFAULT 100;

INSERT INTO public.adj_referral_settings
(id,enabled,signup_bonus_points,points_per_completed_service,rupees_per_point,max_points_per_booking)
VALUES (1,true,100,100,1,100)
ON CONFLICT(id) DO NOTHING;

-- ---------------------------------------------------------
-- REFERRAL EVENTS
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.adj_referral_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  referred_customer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES public.bookings(id) ON DELETE SET NULL,
  event_type text NOT NULL DEFAULT 'completed_service',
  points integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.adj_referral_events
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE public.adj_referral_events ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.adj_referral_events TO authenticated;

DROP POLICY IF EXISTS "ADJ referral events own/admin" ON public.adj_referral_events;
CREATE POLICY "ADJ referral events own/admin"
ON public.adj_referral_events
FOR SELECT TO authenticated
USING (
  referrer_id=auth.uid()
  OR referred_customer_id=auth.uid()
  OR public.get_my_role()='admin'
);

-- ---------------------------------------------------------
-- REWARD LEDGER
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.adj_reward_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  points integer NOT NULL,
  event_type text NOT NULL,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS adj_reward_ledger_customer_idx
ON public.adj_reward_ledger(customer_id,created_at DESC);

ALTER TABLE public.adj_reward_ledger ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.adj_reward_ledger TO authenticated;

DROP POLICY IF EXISTS "ADJ reward ledger own/admin" ON public.adj_reward_ledger;
CREATE POLICY "ADJ reward ledger own/admin"
ON public.adj_reward_ledger
FOR SELECT TO authenticated
USING(customer_id=auth.uid() OR public.get_my_role()='admin');

-- ---------------------------------------------------------
-- GENERATE REFERRAL CODE FOR NEW CUSTOMER PROFILES
-- ---------------------------------------------------------
CREATE OR REPLACE FUNCTION public.adj_make_referral_code()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  c text;
BEGIN
  LOOP
    c := 'ADJ' || upper(substr(encode(gen_random_bytes(4),'hex'),1,6));
    EXIT WHEN NOT EXISTS (
      SELECT 1 FROM public.profiles WHERE referral_code=c
    );
  END LOOP;
  RETURN c;
END;
$$;

CREATE OR REPLACE FUNCTION public.adj_profile_referral_defaults()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
BEGIN
  IF lower(coalesce(NEW.role,''))='customer' AND NULLIF(trim(NEW.referral_code),'') IS NULL THEN
    NEW.referral_code := public.adj_make_referral_code();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_adj_profile_referral_defaults ON public.profiles;
CREATE TRIGGER trg_adj_profile_referral_defaults
BEFORE INSERT ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.adj_profile_referral_defaults();

-- ---------------------------------------------------------
-- AUTOMATIC SIGNUP BONUS
-- ---------------------------------------------------------
CREATE OR REPLACE FUNCTION public.adj_award_signup_bonus()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
DECLARE pts integer;
BEGIN
  IF lower(coalesce(NEW.role,'')) <> 'customer' THEN
    RETURN NEW;
  END IF;

  SELECT COALESCE(signup_bonus_points,100)
  INTO pts
  FROM public.adj_referral_settings
  WHERE id=1;

  pts := COALESCE(pts,100);

  IF pts > 0 THEN
    UPDATE public.profiles
    SET reward_points=COALESCE(reward_points,0)+pts
    WHERE id=NEW.id;

    INSERT INTO public.adj_reward_ledger(customer_id,points,event_type,note)
    VALUES(
      NEW.id,
      pts,
      'signup_bonus',
      'Welcome bonus for creating an ADJ SERVICES customer account'
    );
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_adj_signup_bonus ON public.profiles;
CREATE TRIGGER trg_adj_signup_bonus
AFTER INSERT ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.adj_award_signup_bonus();

-- ---------------------------------------------------------
-- APPLY REFERRAL CODE
-- ---------------------------------------------------------
CREATE OR REPLACE FUNCTION public.customer_apply_referral_code(p_code text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
DECLARE
  me uuid := auth.uid();
  ref uuid;
BEGIN
  IF me IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;

  SELECT id INTO ref
  FROM public.profiles
  WHERE lower(trim(referral_code))=lower(trim(p_code))
    AND lower(coalesce(role,''))='customer'
  LIMIT 1;

  IF ref IS NULL THEN
    RAISE EXCEPTION 'Referral code not found';
  END IF;

  IF ref=me THEN
    RAISE EXCEPTION 'You cannot use your own referral code';
  END IF;

  UPDATE public.profiles
  SET referred_by=ref
  WHERE id=me
    AND lower(coalesce(role,''))='customer'
    AND referred_by IS NULL;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Referral already applied or customer account not found';
  END IF;

  RETURN jsonb_build_object('success',true,'referrer_id',ref);
END;
$$;

REVOKE ALL ON FUNCTION public.customer_apply_referral_code(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.customer_apply_referral_code(text) TO authenticated;

-- ---------------------------------------------------------
-- AUTOMATIC REFERRAL REWARD ON COMPLETED BOOKING
-- ---------------------------------------------------------
CREATE OR REPLACE FUNCTION public.adj_award_referral_on_completed()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
DECLARE
  ref uuid;
  pts integer;
  enabled boolean;
  already boolean;
BEGIN
  IF lower(coalesce(NEW.status,'')) NOT IN ('completed','complete','service completed') THEN
    RETURN NEW;
  END IF;

  IF TG_OP='UPDATE'
     AND lower(coalesce(OLD.status,'')) IN ('completed','complete','service completed') THEN
    RETURN NEW;
  END IF;

  SELECT referred_by INTO ref
  FROM public.profiles
  WHERE id=NEW.customer_id
    AND lower(coalesce(role,''))='customer';

  IF ref IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT COALESCE(enabled,true),COALESCE(points_per_completed_service,100)
  INTO enabled,pts
  FROM public.adj_referral_settings
  WHERE id=1;

  IF NOT COALESCE(enabled,true) OR COALESCE(pts,0)<=0 THEN
    RETURN NEW;
  END IF;

  SELECT EXISTS(
    SELECT 1 FROM public.adj_referral_events
    WHERE booking_id=NEW.id
      AND event_type='completed_service'
  ) INTO already;

  IF already THEN
    RETURN NEW;
  END IF;

  INSERT INTO public.adj_referral_events
  (referrer_id,referred_customer_id,booking_id,event_type,points)
  VALUES
  (ref,NEW.customer_id,NEW.id,'completed_service',pts);

  UPDATE public.profiles
  SET reward_points=COALESCE(reward_points,0)+pts
  WHERE id=ref;

  INSERT INTO public.adj_reward_ledger(customer_id,points,event_type,note)
  VALUES(
    ref,
    pts,
    'referral_completed_service',
    'Reward for referred customer completing a service'
  );

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_adj_award_referral_completed ON public.bookings;
CREATE TRIGGER trg_adj_award_referral_completed
AFTER INSERT OR UPDATE OF status ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.adj_award_referral_on_completed();

-- ---------------------------------------------------------
-- ADMIN ADD/DEDUCT REWARD POINTS
-- ---------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_adjust_reward_points(
  p_customer_id uuid,
  p_points integer,
  p_note text DEFAULT 'Manual Admin adjustment'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
DECLARE
  v_role text;
  v_old integer;
  v_new integer;
  v_name text;
BEGIN
  SELECT lower(coalesce(role,'')) INTO v_role
  FROM public.profiles WHERE id=auth.uid();

  IF v_role <> 'admin' THEN
    RAISE EXCEPTION 'Only Admin can change reward points';
  END IF;

  SELECT full_name,COALESCE(reward_points,0)
  INTO v_name,v_old
  FROM public.profiles
  WHERE id=p_customer_id AND lower(coalesce(role,''))='customer'
  FOR UPDATE;

  IF NOT FOUND THEN RAISE EXCEPTION 'Customer account not found'; END IF;
  IF COALESCE(p_points,0)=0 THEN RAISE EXCEPTION 'Points cannot be zero'; END IF;

  v_new:=v_old+p_points;
  IF v_new<0 THEN
    RAISE EXCEPTION 'Customer does not have enough points. Current balance: %',v_old;
  END IF;

  UPDATE public.profiles
  SET reward_points=v_new,updated_at=now()
  WHERE id=p_customer_id;

  INSERT INTO public.adj_reward_ledger(customer_id,points,event_type,note)
  VALUES(
    p_customer_id,
    p_points,
    CASE WHEN p_points>0 THEN 'admin_points_added' ELSE 'admin_points_deducted' END,
    COALESCE(p_note,'Manual Admin adjustment')
  );

  RETURN jsonb_build_object(
    'success',true,
    'customer_id',p_customer_id,
    'customer_name',v_name,
    'old_points',v_old,
    'changed_points',p_points,
    'new_points',v_new,
    'note',COALESCE(p_note,'')
  );
END;
$$;

REVOKE ALL ON FUNCTION public.admin_adjust_reward_points(uuid,integer,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_adjust_reward_points(uuid,integer,text) TO authenticated;

-- Compatibility signature used by some older admin builds.
CREATE OR REPLACE FUNCTION public.admin_adjust_reward_points(
  p_customer_id uuid,
  p_note text,
  p_points integer
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $$
BEGIN
  RETURN public.admin_adjust_reward_points(p_customer_id,p_points,p_note);
END;
$$;

REVOKE ALL ON FUNCTION public.admin_adjust_reward_points(uuid,text,integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_adjust_reward_points(uuid,text,integer) TO authenticated;

-- ---------------------------------------------------------
-- ADMIN PIN SERVICE AREAS
-- Existing table is preserved. Create only if missing.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.service_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  state text,
  city text,
  area_name text,
  pincodes text[] NOT NULL DEFAULT '{}',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS service_areas_pincodes_gin_idx
ON public.service_areas USING gin(pincodes);

ALTER TABLE public.service_areas ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.service_areas TO authenticated;
GRANT INSERT,UPDATE,DELETE ON public.service_areas TO authenticated;

DROP POLICY IF EXISTS "ADJ service areas read" ON public.service_areas;
CREATE POLICY "ADJ service areas read"
ON public.service_areas
FOR SELECT TO authenticated
USING(true);

DROP POLICY IF EXISTS "ADJ service areas admin write" ON public.service_areas;
CREATE POLICY "ADJ service areas admin write"
ON public.service_areas
FOR ALL TO authenticated
USING(public.get_my_role()='admin')
WITH CHECK(public.get_my_role()='admin');

NOTIFY pgrst,'reload schema';

COMMIT;

-- =========================================================
-- END V17.6
-- =========================================================
