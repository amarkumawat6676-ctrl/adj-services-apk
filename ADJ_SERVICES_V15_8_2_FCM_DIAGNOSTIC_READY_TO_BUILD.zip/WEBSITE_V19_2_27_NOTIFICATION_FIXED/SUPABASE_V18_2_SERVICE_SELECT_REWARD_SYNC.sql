-- =========================================================
-- ADJ SERVICES V18.2
-- SERVICE SELECT + CUSTOMER REWARD REDEMPTION SYNC
-- =========================================================
BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS reward_points_redeemed integer NOT NULL DEFAULT 0;
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS reward_discount numeric(12,2) NOT NULL DEFAULT 0;
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS final_amount numeric(12,2);
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS original_service_charge numeric(12,2) DEFAULT 0;
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS offer_discount numeric(12,2) DEFAULT 0;
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS offer_name text;
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS discount_type text;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS reward_points integer NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS public.adj_reward_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  points integer NOT NULL,
  event_type text NOT NULL,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS adj_reward_ledger_customer_idx
  ON public.adj_reward_ledger(customer_id, created_at DESC);

-- A dedicated RPC avoids old overloaded customer_redeem_points signatures.
CREATE OR REPLACE FUNCTION public.customer_redeem_booking_points_v181(
  p_booking_id uuid,
  p_points integer
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me uuid := auth.uid();
  v_balance integer;
  v_price numeric(12,2);
  v_offer_discount numeric(12,2);
  v_rate numeric(12,2) := 1;
  v_max integer := 100;
  v_points integer;
  v_discount numeric(12,2);
  v_final numeric(12,2);
BEGIN
  IF me IS NULL THEN
    RAISE EXCEPTION 'Login required';
  END IF;
  IF COALESCE(p_points,0) <= 0 THEN
    RAISE EXCEPTION 'Enter a valid number of reward points';
  END IF;

  SELECT COALESCE(reward_points,0)
    INTO v_balance
  FROM public.profiles
  WHERE id=me AND lower(COALESCE(role,''))='customer'
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Customer account not found';
  END IF;

  SELECT COALESCE(estimated_price,0), COALESCE(offer_discount,0)
    INTO v_price, v_offer_discount
  FROM public.bookings
  WHERE id=p_booking_id AND customer_id=me
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Booking not found';
  END IF;

  IF v_offer_discount > 0 THEN
    RAISE EXCEPTION 'Reward points cannot be redeemed together with an offer';
  END IF;

  IF COALESCE((SELECT reward_points_redeemed FROM public.bookings WHERE id=p_booking_id),0) > 0 THEN
    RAISE EXCEPTION 'Reward points have already been redeemed for this booking';
  END IF;

  BEGIN
    SELECT COALESCE(rupees_per_point,1), COALESCE(max_points_per_booking,100)
      INTO v_rate, v_max
    FROM public.adj_referral_settings
    WHERE id=1;
  EXCEPTION WHEN undefined_table THEN
    v_rate := 1;
    v_max := 100;
  END;

  v_rate := GREATEST(0.01,COALESCE(v_rate,1));
  v_max := GREATEST(1,COALESCE(v_max,100));

  IF p_points > v_balance THEN
    RAISE EXCEPTION 'You only have % reward points available', v_balance;
  END IF;

  v_points := LEAST(p_points,v_max);
  v_discount := LEAST(v_price,v_points*v_rate);
  v_final := GREATEST(0,v_price-v_discount);

  UPDATE public.profiles
  SET reward_points=reward_points-v_points,
      updated_at=now()
  WHERE id=me;

  UPDATE public.bookings
  SET reward_points_redeemed=v_points,
      reward_discount=v_discount,
      discount_type='reward',
      final_amount=v_final,
      updated_at=now()
  WHERE id=p_booking_id AND customer_id=me;

  INSERT INTO public.adj_reward_ledger(customer_id,points,event_type,note)
  VALUES(me,-v_points,'booking_redemption','Reward points redeemed on booking '||p_booking_id::text);

  RETURN jsonb_build_object(
    'success',true,
    'booking_id',p_booking_id,
    'points_redeemed',v_points,
    'discount',v_discount,
    'final_amount',v_final,
    'remaining_points',v_balance-v_points
  );
END;
$$;

REVOKE ALL ON FUNCTION public.customer_redeem_booking_points_v181(uuid,integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.customer_redeem_booking_points_v181(uuid,integer) TO authenticated;

-- Keep the manual Admin Add/Deduct system separate from automatic rewards.
CREATE OR REPLACE FUNCTION public.admin_adjust_reward_points_manual(
  p_customer_id uuid,
  p_points integer,
  p_note text DEFAULT 'Manual Admin adjustment'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
  v_old integer;
  v_new integer;
  v_name text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Admin login required'; END IF;
  SELECT lower(COALESCE(role,'')) INTO v_role FROM public.profiles WHERE id=auth.uid();
  IF v_role <> 'admin' THEN RAISE EXCEPTION 'Only Admin can change reward points'; END IF;
  IF COALESCE(p_points,0)=0 THEN RAISE EXCEPTION 'Points change cannot be zero'; END IF;

  SELECT full_name,COALESCE(reward_points,0) INTO v_name,v_old
  FROM public.profiles
  WHERE id=p_customer_id AND lower(COALESCE(role,''))='customer'
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Customer account not found'; END IF;

  v_new:=v_old+p_points;
  IF v_new<0 THEN RAISE EXCEPTION 'Customer does not have enough points. Current balance: %',v_old; END IF;

  UPDATE public.profiles SET reward_points=v_new WHERE id=p_customer_id;
  INSERT INTO public.adj_reward_ledger(customer_id,points,event_type,note)
  VALUES(p_customer_id,p_points,CASE WHEN p_points>0 THEN 'admin_points_added' ELSE 'admin_points_deducted' END,COALESCE(NULLIF(trim(p_note),''),'Manual Admin adjustment'));

  RETURN jsonb_build_object('success',true,'customer_id',p_customer_id,'customer_name',v_name,'old_points',v_old,'changed_points',p_points,'new_points',v_new,'note',COALESCE(p_note,''));
END;
$$;

REVOKE ALL ON FUNCTION public.admin_adjust_reward_points_manual(uuid,integer,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_adjust_reward_points_manual(uuid,integer,text) TO authenticated;

NOTIFY pgrst,'reload schema';
COMMIT;
