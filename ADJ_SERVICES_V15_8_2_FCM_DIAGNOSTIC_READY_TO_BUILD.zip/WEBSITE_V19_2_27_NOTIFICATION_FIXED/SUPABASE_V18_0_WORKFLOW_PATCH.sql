-- ADJ SERVICES V18.0 WORKFLOW PATCH
-- Run only if these columns are not already present.

BEGIN;

ALTER TABLE public.bookings
ADD COLUMN IF NOT EXISTS original_service_charge numeric(12,2) DEFAULT 0;

ALTER TABLE public.bookings
ADD COLUMN IF NOT EXISTS offer_discount numeric(12,2) DEFAULT 0;

ALTER TABLE public.bookings
ADD COLUMN IF NOT EXISTS offer_name text;

ALTER TABLE public.bookings
ADD COLUMN IF NOT EXISTS discount_type text;

ALTER TABLE public.technician_job_sheets
ADD COLUMN IF NOT EXISTS original_service_charge numeric(12,2) DEFAULT 0;

ALTER TABLE public.technician_job_sheets
ADD COLUMN IF NOT EXISTS offer_discount numeric(12,2) DEFAULT 0;

ALTER TABLE public.technician_job_sheets
ADD COLUMN IF NOT EXISTS offer_name text;

ALTER TABLE public.technician_job_sheets
ADD COLUMN IF NOT EXISTS discount_type text;

ALTER TABLE public.technician_job_sheets
ADD COLUMN IF NOT EXISTS warranty_months integer DEFAULT 0;

ALTER TABLE public.technician_job_sheets
ADD COLUMN IF NOT EXISTS warranty_start date;

ALTER TABLE public.technician_job_sheets
ADD COLUMN IF NOT EXISTS warranty_end date;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS offer_discount numeric(12,2) DEFAULT 0;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS offer_name text;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS discount_type text;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS final_amount numeric(12,2) DEFAULT 0;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS technician_id uuid;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS service_name text;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS appliance text;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS work_done text;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS parts_used text;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS before_photo_url text;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS after_photo_url text;

ALTER TABLE public.service_history
ADD COLUMN IF NOT EXISTS technician_notes text;

ALTER TABLE public.customer_appliances
ADD COLUMN IF NOT EXISTS warranty_months integer DEFAULT 0;

ALTER TABLE public.customer_appliances
ADD COLUMN IF NOT EXISTS warranty_type text;

ALTER TABLE public.customer_appliances
ADD COLUMN IF NOT EXISTS source_technician_id uuid;

ALTER TABLE public.customer_appliances
ADD COLUMN IF NOT EXISTS warranty_service_name text;

ALTER TABLE public.customer_appliances
ADD COLUMN IF NOT EXISTS warranty_start_date date;

ALTER TABLE public.customer_appliances
ADD COLUMN IF NOT EXISTS warranty_end_date date;

NOTIFY pgrst, 'reload schema';

COMMIT;
