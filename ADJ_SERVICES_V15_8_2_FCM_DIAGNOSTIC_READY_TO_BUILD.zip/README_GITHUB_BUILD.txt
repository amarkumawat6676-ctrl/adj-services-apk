ADJ SERVICES V15.3 — GITHUB READY

This package contains the complete Android project and a corrected GitHub Actions workflow.
The workflow does NOT use android-actions/setup-android, which was the step failing in the previous run.
It uses the GitHub runner's Android SDK and installs Android 35 directly with sdkmanager.

GitHub:
1. Replace the old repository contents with the contents of this package.
2. Open Actions.
3. Select "Build ADJ SERVICES APK".
4. Tap "Run workflow".
5. When it finishes, download artifact "ADJ-SERVICES-V15.3-release".

No Firebase google-services.json replacement is needed: it is already inside app/.
