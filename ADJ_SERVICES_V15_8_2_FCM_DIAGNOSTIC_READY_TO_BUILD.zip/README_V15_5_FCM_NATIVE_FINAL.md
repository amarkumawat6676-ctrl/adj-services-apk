# ADJ SERVICES V15.6 — Native FCM → Supabase

Native Android FCM token registration is performed directly by the APK.
The APK reads the currently authenticated Supabase session from the WebView (with a localStorage fallback) and writes the FCM token directly to `public.fcm_tokens` using the user's access token and RLS.

No Firebase service-account private key is included in the APK.
