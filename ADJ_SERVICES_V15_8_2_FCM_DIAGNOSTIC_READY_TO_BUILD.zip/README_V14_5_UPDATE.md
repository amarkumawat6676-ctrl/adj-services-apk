# ADJ SERVICES V14.5

- Version: 14.5 (versionCode 18)
- Permanent APK signing key is included so future V14.x builds can update over V14.5 without package-signature conflicts.
- WebView uses normal HTTP cache again for fast repeat loads; the startup URL keeps a timestamp query so the latest website HTML is checked without clearing cookies/local data.
- Customer + Admin + Technician structure is preserved.
- Contextual permissions are preserved.
- APK update downloads support the ADJ Services Pages URL and the official GitHub release download path.

IMPORTANT: The old V14.4 APK was signed with a different key. To move the phone from V14.4 to this stable-signed V14.5 build, uninstall V14.4 once and install V14.5. After that, future V14.x updates can replace the installed app normally.


## Permanent native updater
V14.6 source adds a native startup version check and Android installer flow. Future signed releases can use the same fixed Pages URL and manifest.
