# ADJ SERVICES V15.6 — Native FCM → Supabase Final Candidate

This build keeps FCM registration on the Android native side.

## Registration flow
1. Firebase Messaging generates/retrieves the native FCM token.
2. Android reads the persisted Supabase Auth session from the WebView localStorage.
3. Android uses the customer's Supabase access JWT with the publishable key.
4. Android writes/upserts the token directly to `public.fcm_tokens` through the Supabase REST API.
5. If the access token is expired, Android refreshes it with the persisted Supabase refresh token and retries.
6. Registration is retried while the app is open, so login after initial page load is covered.

The hosted `window.onADJFcmToken` callback is not required for the native registration path.

## Supabase requirements already included
- `public.fcm_tokens` authenticated INSERT/UPDATE policies
- authenticated table grants
- unique token index
- service-role access for server-side push delivery

## Security
- No Firebase service-account private key is bundled in the APK.
- The Supabase publishable key is client-safe when protected by RLS.
- The Supabase service-role/Firebase service-account secrets remain server-side.
