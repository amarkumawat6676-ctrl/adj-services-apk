package in.adjservices.app;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.ActivityNotFoundException;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import android.content.Context;

import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_NOTIFICATION = 100;
    private static final int REQ_LOCATION = 101;
    private static final int REQ_MEDIA = 102;
    private static final int REQ_CAMERA_AUDIO = 103;
    private boolean notificationRequestInProgress = false;
    private boolean customerNotificationPromptShownThisSession = false;
    private static final String UPDATE_MANIFEST_URL = "https://api.github.com/repos/amarkumawat6676-ctrl/adj-services-apk/releases/latest";
    private static final String PREFS = "adj_update";
    private static final String PREF_DOWNLOAD_ID = "download_id";

    // Native FCM -> Supabase registration. The publishable key is safe to ship in the APK;
    // the user's short-lived Supabase access token is used with RLS for the actual write.
    private static final String SUPABASE_URL =
            "https://hnmqthakuqkrtnfwdtjo.supabase.co";
    private static final String SUPABASE_PUBLISHABLE_KEY =
            "sb_publishable_U8XDG6346jLAvCp0X8uzkg_TKdjf71q";
    private static final String PREFS_FCM = "adj_fcm";
    private static final String PREF_FCM_TOKEN = "fcm_token";
    private String lastRegisteredFcmUserId = "";
    private String lastRegisteredFcmToken = "";
    private boolean nativeFcmRegistrationWatcherStarted = false;

    // Diagnostic-only state for the one-off FCM troubleshooting build.
    private final StringBuilder fcmDiagLog = new StringBuilder();
    private TextView fcmDiagTextView;
    private volatile String diagLastFcmToken = "";
    private volatile String diagLastUserId = "";
    private volatile String diagLastHttp = "";
    private volatile String diagLastHttpBody = "";
    private volatile String diagLastSessionHandoff = "";

    private WebView webView;
    private static MainActivity activeInstance;
    private FrameLayout root;
    private PermissionRequest pendingWebPermission;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private ValueCallback<Uri[]> filePathCallback;
    private WebChromeClient.FileChooserParams pendingFileChooserParams;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activeInstance = this;
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(11, 59, 130));
        window.setNavigationBarColor(Color.rgb(246, 248, 252));
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);
        setupWebView();
        requestNativeFcmToken();
        scheduleNativeFcmRegistrationCheck();
    }

    @Override protected void onResume() {
        super.onResume();
        checkCompletedUpdateDownload();
        requestNativeFcmToken();
        if (webView != null) {
            webView.postDelayed(this::registerLatestFcmTokenWithSupabase, 1500);
        }
    }

    private void setupWebView() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setFitsSystemWindows(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        root.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        addFcmDiagnosticButton();

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars() | WindowInsets.Type.displayCutout());
                top = bars.top; bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop(); bottom = insets.getSystemWindowInsetBottom();
            }
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) webView.getLayoutParams();
            params.topMargin = top; params.bottomMargin = bottom;
            webView.setLayoutParams(params);
            return insets;
        });
        root.post(() -> root.requestApplyInsets());

        WebSettings s = webView.getSettings();
        s.setUserAgentString(s.getUserAgentString() + " ADJServicesAPK/15.8");
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setLoadsImagesAutomatically(true);
        s.setBlockNetworkImage(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new ADJNativeBridge(), "ADJNative");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onConsoleMessage(android.webkit.ConsoleMessage cm) {
                if (cm != null) appendFcmDiag("WEB CONSOLE: " + cm.message() + " (" + cm.lineNumber() + ")");
                return true;
            }

            @Override public void onPermissionRequest(PermissionRequest request) {
                // Only request Android permissions when the webpage explicitly asks for them.
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }

            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                // Location permission is requested only when the webpage invokes geolocation.
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }

            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                pendingFileChooserParams = params;
                // Android's system picker is used for files/photos. No storage permission is requested here.
                try {
                    startActivityForResult(params.createIntent(), REQ_MEDIA);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "File picker not available", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // The APK loads the live hosted website. The native APK must therefore
                // not depend on a particular website build to trigger notification permission.
                // Poll the live Supabase session and request notification permission once
                // when a CUSTOMER session is detected after login/create-account.
                scheduleCustomerNotificationPermissionCheck();
                requestNativeFcmToken();
                if (webView != null) {
                    webView.postDelayed(MainActivity.this::registerLatestFcmTokenWithSupabase, 1800);
                    webView.postDelayed(MainActivity.this::registerLatestFcmTokenWithSupabase, 4500);
                    scheduleNativeFcmRegistrationCheck();
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return handleExternal(request.getUrl().toString()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return handleExternal(url); }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (isAllowedApkDownloadUrl(url)) {
                downloadApk(url);
            } else if (url != null) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "Unable to open download link", Toast.LENGTH_SHORT).show(); }
            }
        });
        loadLatestWebsite();
        root.postDelayed(this::checkForNativeUpdate, 1800);
    }

    /**
     * Always ask the hosted site for the newest document when the APK starts.
     * This bypasses WebView HTTP cache without clearing cookies, local storage,
     * Supabase sessions, or customer data. The website/service-worker still
     * provides its own offline fallback when the network is unavailable.
     */
    private void loadLatestWebsite() {
        String refreshUrl = "https://adjservices.pages.dev/?apk_refresh=" + System.currentTimeMillis();
        webView.loadUrl(refreshUrl);
    }

    private boolean isAllowedApkDownloadUrl(String url) {
        if (url == null) return false;
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            String path = uri.getPath() == null ? "" : uri.getPath();
            boolean https = "https".equalsIgnoreCase(uri.getScheme());
            boolean pages = "adjservices.pages.dev".equalsIgnoreCase(host);
            boolean githubLatest = "github.com".equalsIgnoreCase(host)
                    && path.startsWith("/amarkumawat6676-ctrl/adj-services-apk/releases/")
                    && path.endsWith("/ADJ-SERVICES.apk");
            return https && (pages || githubLatest);
        } catch (Exception e) {
            return false;
        }
    }

    private void checkForNativeUpdate() {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(UPDATE_MANIFEST_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setRequestMethod("GET");
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setRequestProperty("User-Agent", "ADJ-SERVICES-Android-Updater");
                if (c.getResponseCode() != 200) return;
                InputStream in = c.getInputStream();
                byte[] buf = new byte[8192]; StringBuilder out = new StringBuilder(); int n;
                while ((n = in.read(buf)) > 0) out.append(new String(buf, 0, n, java.nio.charset.StandardCharsets.UTF_8));
                in.close();
                JSONObject release = new JSONObject(out.toString());
                String tag = release.optString("tag_name", "").trim();
                String latest = tag.replaceFirst("^[vV]", "").trim();
                long latestCode = -1;
                try {
                    String releaseNotes = release.optString("body", "");
                    java.util.regex.Matcher vm = java.util.regex.Pattern
                            .compile("(?i)versionCode\\s*[:=]\\s*(\\d+)")
                            .matcher(releaseNotes);
                    if (vm.find()) latestCode = Long.parseLong(vm.group(1));
                } catch (Exception ignored) {}
                if (latest.isEmpty()) return;
                String apkUrl = "";
                org.json.JSONArray assets = release.optJSONArray("assets");
                if (assets != null) {
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject a = assets.optJSONObject(i);
                        String name = a == null ? "" : a.optString("name", "");
                        if ("ADJ-SERVICES.apk".equalsIgnoreCase(name)) { apkUrl = a.optString("browser_download_url", ""); break; }
                    }
                }
                if (apkUrl.isEmpty()) return;
                android.content.pm.PackageInfo installedInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
                String current = installedInfo.versionName == null ? "0.0" : installedInfo.versionName;
                long currentCode = android.os.Build.VERSION.SDK_INT >= 28 ? installedInfo.getLongVersionCode() : installedInfo.versionCode;
                boolean newer = latestCode > 0 ? latestCode > currentCode : isNewerVersion(current, latest);
                if (newer && isAllowedApkDownloadUrl(apkUrl)) {
                    final String latestVersionForUi = latest;
                    final String apkUrlForUi = apkUrl;
                    final String messageForUi = release.optString("body", "A new ADJ SERVICES app update is available.");
                    runOnUiThread(() -> showUpdateDialog(latestVersionForUi, apkUrlForUi, messageForUi, false));
                }
            } catch (Exception e) {
                android.util.Log.w("ADJ_UPDATE", "Update check failed", e);
            } finally { if (c != null) c.disconnect(); }
        }).start();
    }

    private boolean isNewerVersion(String current, String latest) {
        try {
            String[] a=current.split("\\."), b=latest.split("\\.");
            int m=Math.max(a.length,b.length);
            for(int i=0;i<m;i++){ int x=i<a.length?Integer.parseInt(a[i].replaceAll("[^0-9].*","")):0; int y=i<b.length?Integer.parseInt(b[i].replaceAll("[^0-9].*","")):0; if(y>x)return true; if(y<x)return false; }
        } catch(Exception e){ return !current.equals(latest); }
        return false;
    }

    private void showUpdateDialog(String latest, String url, String message, boolean force) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("ADJ SERVICES Update");
        b.setMessage(message + "\n\nCurrent version: " + getVersionName() + "\nNew version: " + latest);
        b.setPositiveButton("UPDATE NOW", (d,w) -> downloadApk(url));
        if (!force) b.setNegativeButton("LATER", null);
        AlertDialog dialog=b.create();
        dialog.setCanceledOnTouchOutside(!force); dialog.setCancelable(!force); dialog.show();
    }

    private String getVersionName(){ try{return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception e){return "0.0";} }

    private void downloadApk(String url) {
        if (!isAllowedApkDownloadUrl(url)) { Toast.makeText(this, "Invalid update link", Toast.LENGTH_SHORT).show(); return; }
        try {
            DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));
            r.setTitle("ADJ SERVICES Update"); r.setDescription("Downloading the latest ADJ SERVICES app");
            r.setMimeType("application/vnd.android.package-archive");
            r.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI|DownloadManager.Request.NETWORK_MOBILE);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "ADJ-SERVICES-latest.apk");
            long id=dm.enqueue(r); getSharedPreferences(PREFS,MODE_PRIVATE).edit().putLong(PREF_DOWNLOAD_ID,id).apply();
            Toast.makeText(this,"Update download started.",Toast.LENGTH_LONG).show();
        } catch(Exception e){ Toast.makeText(this,"Download failed: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void checkCompletedUpdateDownload(){
        long id=getSharedPreferences(PREFS,MODE_PRIVATE).getLong(PREF_DOWNLOAD_ID,-1); if(id<0)return;
        try{
            DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Query q=new DownloadManager.Query().setFilterById(id);
            android.database.Cursor c=dm.query(q);
            if(c!=null && c.moveToFirst()){
                int status=c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                if(status==DownloadManager.STATUS_SUCCESSFUL){
                    String uri=c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
                    getSharedPreferences(PREFS,MODE_PRIVATE).edit().remove(PREF_DOWNLOAD_ID).apply();
                    c.close();
                    Uri apkUri=Uri.parse(uri);
                    String validation=validateUpdateApk(apkUri);
                    if(!"OK".equals(validation)){
                        Toast.makeText(this, validation, Toast.LENGTH_LONG).show();
                        return;
                    }
                    installApk(apkUri);
                    return;
                }
                if(status==DownloadManager.STATUS_FAILED){
                    getSharedPreferences(PREFS,MODE_PRIVATE).edit().remove(PREF_DOWNLOAD_ID).apply();
                    Toast.makeText(this,"Update download failed. Please try again.",Toast.LENGTH_LONG).show();
                }
            }
            if(c!=null)c.close();
        }catch(Exception e){
            Toast.makeText(this,"Could not prepare the update: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private java.io.File materializeDownloadedApk(Uri uri) throws Exception {
        if (uri == null) throw new IllegalArgumentException("Missing APK URI");
        if ("file".equalsIgnoreCase(uri.getScheme())) return new java.io.File(uri.getPath());
        java.io.File out = new java.io.File(getCacheDir(), "ADJ-SERVICES-update.apk");
        try (InputStream in = getContentResolver().openInputStream(uri); java.io.FileOutputStream fos = new java.io.FileOutputStream(out)) {
            if (in == null) throw new IllegalArgumentException("Downloaded APK cannot be opened");
            byte[] b = new byte[8192]; int n;
            while ((n = in.read(b)) > 0) fos.write(b, 0, n);
        }
        return out;
    }

    private String validateUpdateApk(Uri localUri){
        try{
            java.io.File apk = materializeDownloadedApk(localUri);
            android.content.pm.PackageManager pm=getPackageManager();
            android.content.pm.PackageInfo installed=pm.getPackageInfo(getPackageName(), android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES);
            android.content.pm.PackageInfo archive=pm.getPackageArchiveInfo(apk.getAbsolutePath(), android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES);
            if(archive==null) return "Downloaded update is not a valid Android APK.";
            if(!getPackageName().equals(archive.packageName)) return "Update package does not belong to ADJ SERVICES.";
            long installedCode=android.os.Build.VERSION.SDK_INT>=28?installed.getLongVersionCode():installed.versionCode;
            long archiveCode=android.os.Build.VERSION.SDK_INT>=28?archive.getLongVersionCode():archive.versionCode;
            if(archiveCode<=installedCode) return "Downloaded APK is not newer than the installed app.";
            if(android.os.Build.VERSION.SDK_INT>=28){
                android.content.pm.SigningInfo a=archive.signingInfo, i=installed.signingInfo;
                android.content.pm.Signature[] as=a.hasMultipleSigners()?a.getApkContentsSigners():a.getSigningCertificateHistory();
                android.content.pm.Signature[] is=i.hasMultipleSigners()?i.getApkContentsSigners():i.getSigningCertificateHistory();
                boolean match=false;
                if(as!=null&&is!=null) for(android.content.pm.Signature x:as) for(android.content.pm.Signature y:is) if(x.equals(y)) match=true;
                if(!match) return "This update is signed with a different certificate. The installed app cannot be updated by this APK.";
            }
            return "OK";
        }catch(Exception e){
            android.util.Log.e("ADJ_UPDATE", "APK validation failed", e);
            return "Could not verify the downloaded update.";
        }
    }

    private void installApk(Uri localUri){
        try{
            java.io.File apk = materializeDownloadedApk(localUri);
            Uri contentUri=FileProvider.getUriForFile(this,"in.adjservices.app.fileprovider",apk);
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(contentUri,"application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_ACTIVITY_NEW_TASK);
            if(Build.VERSION.SDK_INT>=26 && !getPackageManager().canRequestPackageInstalls()){
                new AlertDialog.Builder(this).setTitle("Allow app updates").setMessage("Android needs permission to install the ADJ SERVICES update. Please allow it once in the next screen.").setPositiveButton("OPEN SETTINGS",(d,w)->{Intent s=new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName()));startActivity(s);}).setNegativeButton("CANCEL",null).show();
                return;
            }
            startActivity(i);
        }catch(Exception e){
            android.util.Log.e("ADJ_UPDATE", "Unable to open installer", e);
            Toast.makeText(this,"Unable to open the update installer",Toast.LENGTH_LONG).show();
        }
    }

    private class ADJNativeBridge {
        @JavascriptInterface
        public String getAppVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "0.0";
            }
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> requestNotificationPermissionOnce());
        }

        @JavascriptInterface
        public void requestFcmToken() {
            // Kept for compatibility with older hosted pages. Registration itself is now
            // handled natively and does not depend on window.onADJFcmToken().
            requestNativeFcmToken();
        }

        @JavascriptInterface
        public void registerFcmSession(String userId, String accessToken, String refreshToken) {
            appendFcmDiag("BRIDGE registerFcmSession() called");
            diagLastUserId = userId == null ? "" : userId.trim();
            if (userId == null || userId.trim().isEmpty() || accessToken == null || accessToken.trim().isEmpty()) {
                appendFcmDiag("FAIL: user_id/access_token missing");
                android.util.Log.w("ADJ_FCM", "Native session registration skipped: missing user/session");
                return;
            }
            String token = getSharedPreferences(PREFS_FCM, MODE_PRIVATE)
                    .getString(PREF_FCM_TOKEN, "");
            if (token == null || token.isEmpty()) {
                appendFcmDiag("FAIL: native FCM token not available yet");
                requestNativeFcmToken();
                return;
            }
            appendFcmDiag("PASS: session + native token available; sending to Supabase");
            sendFcmTokenToSupabase(token, userId.trim(), accessToken.trim(),
                    refreshToken == null ? "" : refreshToken.trim(), true);
        }

        @JavascriptInterface
        public boolean isNativeFcmAvailable() {
            return true;
        }

        @JavascriptInterface
        public void downloadLatestApk(String url) {
            downloadApk(url);
        }
    }

    /**
     * Gets the native Firebase token and keeps the latest value locally.
     * No hosted-page callback is required for token acquisition or persistence.
     */
    private void requestNativeFcmToken() {
        try {
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful()) {
                    String msg = task.getException() == null ? "unknown" : String.valueOf(task.getException().getMessage());
                    appendFcmDiag("FAIL: FCM token generation: " + msg);
                    android.util.Log.w("ADJ_FCM", "FCM token request failed", task.getException());
                    return;
                }
                String token = task.getResult();
                if (token == null || token.isEmpty()) {
                    appendFcmDiag("FAIL: FCM returned empty token");
                    return;
                }
                diagLastFcmToken = token;
                appendFcmDiag("PASS: FCM token generated (" + maskToken(token) + ")");

                getSharedPreferences(PREFS_FCM, MODE_PRIVATE)
                        .edit()
                        .putString(PREF_FCM_TOKEN, token)
                        .apply();

                // Keep legacy WebView compatibility, but do not depend on it for Supabase.
                pushFcmTokenToWebView(token);
                registerLatestFcmTokenWithSupabase();
            });
        } catch (Exception e) {
            android.util.Log.w("ADJ_FCM", "Native FCM setup failed", e);
        }
    }

    /**
     * Native FCM registration path.
     * The WebView's live Supabase client supplies the current authenticated session directly
     * to the native bridge. No Supabase localStorage parsing is used.
     */
    private void registerLatestFcmTokenWithSupabase() {
        if (webView == null || isFinishing()) return;
        String token = getSharedPreferences(PREFS_FCM, MODE_PRIVATE).getString(PREF_FCM_TOKEN, "");
        if (token == null || token.isEmpty()) return;

        String js = "(async function(){try{" +
                "if(typeof sb==='undefined'||!sb||!sb.auth)return JSON.stringify({ok:false,reason:'supabase_not_ready'});" +
                "let r=await sb.auth.getSession();let s=r&&r.data?r.data.session:null;" +
                "if(!s||!s.user||!s.access_token){" +
                "try{r=await sb.auth.refreshSession();s=r&&r.data?r.data.session:null;}catch(e){}" +
                "}" +
                "if(!s||!s.user||!s.access_token)return JSON.stringify({ok:false,reason:'no_authenticated_session'});" +
                "if(window.ADJNative&&typeof window.ADJNative.registerFcmSession==='function'){" +
                "window.ADJNative.registerFcmSession(String(s.user.id),String(s.access_token),String(s.refresh_token||''));" +
                "return JSON.stringify({ok:true,user_id:String(s.user.id)});}" +
                "return JSON.stringify({ok:false,reason:'native_bridge_missing'});" +
                "}catch(e){return JSON.stringify({ok:false,reason:String(e)})}})()";
        try {
            webView.evaluateJavascript(js, value -> {
                diagLastSessionHandoff = value == null ? "" : value;
                appendFcmDiag("SESSION HANDOFF: " + value);
                android.util.Log.d("ADJ_FCM", "Session handoff: " + value);
            });
        } catch (Exception e) {
            appendFcmDiag("FAIL: evaluateJavascript: " + e.getMessage());
            android.util.Log.w("ADJ_FCM", "Could not request native session handoff", e);
        }
    }

    private void refreshSupabaseSession(String refreshToken, String userId, String fcmToken) {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL(SUPABASE_URL + "/auth/v1/token?grant_type=refresh_token");
                c = (HttpURLConnection) url.openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(10000);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY);
                c.setRequestProperty("Content-Type", "application/json");

                JSONObject payload = new JSONObject();
                payload.put("refresh_token", refreshToken);
                byte[] body = payload.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
                c.getOutputStream().write(body);
                c.getOutputStream().flush();
                c.getOutputStream().close();

                int code = c.getResponseCode();
                InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                StringBuilder out = new StringBuilder();
                if (in != null) {
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.append(new String(buf, 0, n, java.nio.charset.StandardCharsets.UTF_8));
                    }
                    in.close();
                }
                if (code >= 200 && code < 300) {
                    JSONObject r = new JSONObject(out.toString());
                    String accessToken = r.optString("access_token", "");
                    String returnedUserId = r.optJSONObject("user") != null
                            ? r.getJSONObject("user").optString("id", userId) : userId;
                    if (!accessToken.isEmpty()) {
                        sendFcmTokenToSupabase(fcmToken, returnedUserId, accessToken, "", false);
                        android.util.Log.d("ADJ_FCM", "Supabase session refreshed successfully");
                    }
                } else {
                    android.util.Log.e("ADJ_FCM", "Supabase session refresh failed: HTTP " + code + " " + out);
                }
            } catch (Exception e) {
                android.util.Log.e("ADJ_FCM", "Supabase session refresh error", e);
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }

    private void sendFcmTokenToSupabase(String token, String userId, String accessToken,
                                        String refreshToken, boolean allowRefreshRetry) {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                URL url = new URL(SUPABASE_URL + "/rest/v1/fcm_tokens?on_conflict=token");
                c = (HttpURLConnection) url.openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(10000);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY);
                c.setRequestProperty("Authorization", "Bearer " + accessToken);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Prefer", "resolution=merge-duplicates,return=minimal");

                JSONObject payload = new JSONObject();
                payload.put("user_id", userId);
                payload.put("token", token);
                payload.put("device_model", Build.MANUFACTURER + " " + Build.MODEL);
                payload.put("platform", "android");
                payload.put("updated_at", new java.text.SimpleDateFormat(
                        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US)
                        .format(new java.util.Date()));

                byte[] body = payload.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8);
                c.getOutputStream().write(body);
                c.getOutputStream().flush();
                c.getOutputStream().close();

                int code = c.getResponseCode();
                InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                StringBuilder out = new StringBuilder();
                if (in != null) {
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.append(new String(buf, 0, n, java.nio.charset.StandardCharsets.UTF_8));
                    }
                    in.close();
                }

                diagLastHttp = "HTTP " + code;
                diagLastHttpBody = out.toString();
                if (code >= 200 && code < 300) {
                    appendFcmDiag("PASS: Supabase fcm_tokens INSERT → HTTP " + code);
                    lastRegisteredFcmUserId = userId;
                    lastRegisteredFcmToken = token;
                    getSharedPreferences(PREFS_FCM, MODE_PRIVATE)
                            .edit()
                            .putString("registered_user_id", userId)
                            .putString("registered_token", token)
                            .apply();
                    android.util.Log.d("ADJ_FCM", "FCM token registered in Supabase: HTTP " + code);
                } else if ((code == 401 || code == 403) && allowRefreshRetry && refreshToken != null && !refreshToken.isEmpty()) {
                    appendFcmDiag("FAIL: Supabase rejected token → HTTP " + code + " " + out);
                    android.util.Log.w("ADJ_FCM", "Supabase rejected access token; refreshing and retrying");
                    refreshSupabaseSession(refreshToken, userId, token);
                } else {
                    appendFcmDiag("FAIL: Supabase fcm_tokens INSERT → HTTP " + code + " " + out);
                    android.util.Log.e("ADJ_FCM",
                            "Supabase FCM registration failed: HTTP " + code + " " + out);
                }
            } catch (Exception e) {
                appendFcmDiag("FAIL: Supabase request exception: " + e.getClass().getSimpleName() + ": " + e.getMessage());
                android.util.Log.e("ADJ_FCM", "Supabase FCM registration error", e);
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }

    /**
     * Watches the WebView session so registration also happens when the customer logs in
     * after the initial page load. It only performs the REST write when user/token changes.
     */
    private void scheduleNativeFcmRegistrationCheck() {
        if (webView == null || nativeFcmRegistrationWatcherStarted) return;
        nativeFcmRegistrationWatcherStarted = true;
        webView.postDelayed(new Runnable() {
            @Override public void run() {
                if (isFinishing() || webView == null) return;
                registerLatestFcmTokenWithSupabase();
                webView.postDelayed(this, 3000);
            }
        }, 2500);
    }

    public static void registerNativeFcmTokenFromService() {
        MainActivity a = activeInstance;
        if (a == null) return;
        a.runOnUiThread(a::registerLatestFcmTokenWithSupabase);
    }

    public static void pushFcmTokenToWebView(String token) {
        MainActivity a = activeInstance;
        if (a == null || a.webView == null || token == null || token.isEmpty()) return;
        String js = "(function(){try{if(window.onADJFcmToken)window.onADJFcmToken(" +
                JSONObject.quote(token) + ");}catch(e){}})()";
        a.runOnUiThread(() -> {
            try { a.webView.evaluateJavascript(js, null); } catch (Exception ignored) {}
        });
    }

    private String maskToken(String token) {
        if (token == null || token.isEmpty()) return "none";
        if (token.length() <= 8) return "********";
        return "********" + token.substring(token.length() - 8);
    }

    private void appendFcmDiag(String line) {
        synchronized (fcmDiagLog) {
            String time = new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(new java.util.Date());
            fcmDiagLog.append(time).append("  ").append(line).append("\n");
            if (fcmDiagLog.length() > 12000) fcmDiagLog.delete(0, fcmDiagLog.length() - 12000);
        }
        if (fcmDiagTextView != null) runOnUiThread(() -> {
            if (fcmDiagTextView != null) {
                synchronized (fcmDiagLog) { fcmDiagTextView.setText(fcmDiagLog.toString()); }
            }
        });
    }

    private void addFcmDiagnosticButton() {
        Button b = new Button(this);
        b.setText("FCM DIAG");
        b.setTextSize(11f);
        b.setAllCaps(false);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.END;
        lp.setMargins(0, 0, 16, 24);
        root.addView(b, lp);
        b.setOnClickListener(v -> showFcmDiagnosticDialog());
    }

    private void showFcmDiagnosticDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(12 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);

        TextView summary = new TextView(this);
        summary.setTextSize(14f);
        summary.setText(
                "Native token: " + maskToken(diagLastFcmToken) + "\n" +
                "User ID: " + (diagLastUserId.isEmpty() ? "not received" : diagLastUserId) + "\n" +
                "Last HTTP: " + (diagLastHttp.isEmpty() ? "none" : diagLastHttp) + "\n" +
                "Session handoff: " + (diagLastSessionHandoff.isEmpty() ? "none" : diagLastSessionHandoff));
        box.addView(summary);

        fcmDiagTextView = new TextView(this);
        fcmDiagTextView.setTextSize(12f);
        fcmDiagTextView.setTextIsSelectable(true);
        fcmDiagTextView.setTextColor(Color.DKGRAY);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(fcmDiagTextView, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        sp.topMargin = pad;
        box.addView(scroll, sp);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("FCM Diagnostic — 15.8.2")
                .setView(box)
                .setPositiveButton("RUN TEST", null)
                .setNeutralButton("CLEAR", (d, w) -> { synchronized (fcmDiagLog) { fcmDiagLog.setLength(0); } appendFcmDiag("Diagnostic log cleared"); })
                .setNegativeButton("CLOSE", null)
                .create();
        dialog.setOnShowListener(d -> {
            TextView tv = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            tv.setOnClickListener(v -> runFcmDiagnosticTest(summary, scroll));
            synchronized (fcmDiagLog) { fcmDiagTextView.setText(fcmDiagLog.toString()); }
        });
        dialog.show();
    }

    private void runFcmDiagnosticTest(TextView summary, ScrollView scroll) {
        appendFcmDiag("========== MANUAL TEST START ==========");
        requestNativeFcmToken();
        if (webView == null) {
            appendFcmDiag("FAIL: WebView is null");
            return;
        }
        String js = "(async function(){try{" +
                "let out={};" +
                "out.href=location.href;" +
                "out.sbType=typeof sb;" +
                "out.sbAuth=!!(typeof sb!=='undefined'&&sb&&sb.auth);" +
                "out.bridge=!!(window.ADJNative&&typeof window.ADJNative.registerFcmSession==='function');" +
                "if(out.sbAuth){let r=await sb.auth.getSession();let s=r&&r.data?r.data.session:null;out.hasSession=!!s;out.userId=s&&s.user?s.user.id:null;out.hasAccessToken=!!(s&&s.access_token);out.hasRefreshToken=!!(s&&s.refresh_token);}else{out.hasSession=false;}" +
                "return JSON.stringify(out);}catch(e){return JSON.stringify({error:String(e)})}})()";
        webView.evaluateJavascript(js, value -> {
            appendFcmDiag("WEBVIEW STATE: " + value);
            runOnUiThread(() -> {
                if (summary != null) summary.setText(
                        "Native token: " + maskToken(diagLastFcmToken) + "\n" +
                        "User ID: " + (diagLastUserId.isEmpty() ? "not received" : diagLastUserId) + "\n" +
                        "Last HTTP: " + (diagLastHttp.isEmpty() ? "none" : diagLastHttp) + "\n" +
                        "Session handoff: " + (diagLastSessionHandoff.isEmpty() ? "none" : diagLastSessionHandoff));
                if (fcmDiagTextView != null) synchronized (fcmDiagLog) { fcmDiagTextView.setText(fcmDiagLog.toString()); }
                if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
            });
        });
    }

    // Notification permission is requested only from an explicit customer login/create-account
    // signal coming from the hosted website. Do not persist a "requested" flag: older APKs
    // may already have stored that flag even when Android never displayed the dialog.
    private void scheduleCustomerNotificationPermissionCheck() {
        // Safety net for the hosted WebView: the website normally calls the native
        // bridge immediately after successful customer login/create-account.
        // This watcher only acts after the customer screen becomes authenticated.
        webView.postDelayed(new Runnable() {
            @Override public void run() {
                if (isFinishing() || webView == null) return;
                try {
                    webView.evaluateJavascript(
                        "(function(){try{if(typeof state!=='undefined' && state && state.user && state.user.id)return true;}catch(e){} var s=document.querySelector('#customer.screen.active');var n=document.querySelector('#accountName, #profileName');var t=n?n.textContent:'';return !!s && !!t && !/guest customer|login to manage/i.test(t);})()",
                        value -> {
                            if ("true".equals(value) && !customerNotificationPromptShownThisSession) {
                                customerNotificationPromptShownThisSession = true;
                                requestNotificationPermissionOnce();
                            }
                        });
                } catch (Exception ignored) {}
                if (webView != null) webView.postDelayed(this, 1200);
            }
        }, 1200);
    }

    private void requestNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (hasPermission(Manifest.permission.POST_NOTIFICATIONS)) return;
        if (notificationRequestInProgress) return;

        // If Android has stopped showing the runtime dialog after a previous denial,
        // give the customer a clear native route to enable notifications.
        if (!shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)
                && getPreferences(MODE_PRIVATE).getBoolean("notification_attempted", false)) {
            showNotificationSettingsDialog();
            return;
        }

        notificationRequestInProgress = true;
        getPreferences(MODE_PRIVATE).edit().putBoolean("notification_attempted", true).apply();
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
    }

    private void showNotificationSettingsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Notifications are off")
                .setMessage("Please allow notifications for ADJ SERVICES so you can receive booking and chat updates.")
                .setNegativeButton("LATER", null)
                .setPositiveButton("OPEN SETTINGS", (d, w) -> {
                    try {
                        Intent i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                        i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, getPackageName());
                        startActivity(i);
                    } catch (Exception e) {
                        try { startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); } catch (Exception ignored) {}
                    }
                }).show();
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        if (request == null) return;
        List<String> needed = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && !hasPermission(Manifest.permission.CAMERA)) needed.add(Manifest.permission.CAMERA);
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && !hasPermission(Manifest.permission.RECORD_AUDIO)) needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (needed.isEmpty()) {
            request.grant(request.getResources());
        } else {
            pendingWebPermission = request;
            requestPermissions(needed.toArray(new String[0]), REQ_CAMERA_AUDIO);
        }
    }

    private boolean hasPermission(String permission) { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED; }
    private boolean hasLocationPermission() { return hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) || hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION); }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            boolean ok = hasLocationPermission();
            if (pendingGeoCallback != null) pendingGeoCallback.invoke(pendingGeoOrigin, ok, false);
            pendingGeoCallback = null; pendingGeoOrigin = null;
        } else if (requestCode == REQ_CAMERA_AUDIO) {
            PermissionRequest request = pendingWebPermission;
            pendingWebPermission = null;
            if (request != null) {
                boolean ok = true;
                for (String resource : request.getResources()) {
                    if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && !hasPermission(Manifest.permission.CAMERA)) ok = false;
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && !hasPermission(Manifest.permission.RECORD_AUDIO)) ok = false;
                }
                if (ok) request.grant(request.getResources()); else request.deny();
            }
        } else if (requestCode == REQ_NOTIFICATION) {
            notificationRequestInProgress = false;
            if (hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
                getPreferences(MODE_PRIVATE).edit().putBoolean("notification_attempted", false).apply();
            }
        }
    }

    private boolean handleExternal(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        boolean external = scheme.equals("tel") || scheme.equals("mailto") || scheme.equals("whatsapp") || scheme.equals("geo") ||
                url.startsWith("https://wa.me/") || url.startsWith("https://maps.google.com/") || url.startsWith("https://www.google.com/maps/");
        if (!external) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "Required app is not installed", Toast.LENGTH_SHORT).show(); }
        return true;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_MEDIA && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            pendingFileChooserParams = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (activeInstance == this) activeInstance = null;
        if (webView != null) { webView.loadUrl("about:blank"); webView.destroy(); }
        super.onDestroy();
    }
}
