package in.adjservices.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

public class ADJFirebaseMessagingService extends FirebaseMessagingService {
    public static final String CHANNEL_ID = "adj_services_alerts";

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        getSharedPreferences("adj_fcm", MODE_PRIVATE)
                .edit()
                .putString("fcm_token", token)
                .apply();
        android.util.Log.d("ADJ_FCM", "FCM token refreshed and saved locally");

        MainActivity.registerNativeFcmTokenFromService();
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);

        String title = message.getNotification() != null && message.getNotification().getTitle() != null
                ? message.getNotification().getTitle() : "ADJ SERVICES";
        String body = message.getNotification() != null && message.getNotification().getBody() != null
                ? message.getNotification().getBody() : "You have a new ADJ SERVICES update.";

        Map<String, String> data = message.getData();
        String url = data != null && data.get("url") != null ? data.get("url") : "https://adjservices.pages.dev/";

        createChannel();

        Intent intent = new Intent(this, MainActivity.class);
        intent.setAction(Intent.ACTION_VIEW);
        intent.putExtra("notification_url", url);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        PendingIntent pi = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.adj_icon)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

        try {
            NotificationManagerCompat.from(this).notify((int) (System.currentTimeMillis() & 0x7fffffff), builder.build());
        } catch (SecurityException ignored) {
            // Android 13+ permission is controlled by MainActivity.
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "ADJ SERVICES Alerts", NotificationManager.IMPORTANCE_HIGH
                );
                channel.setDescription("Booking, chat and service updates");
                channel.enableVibration(true);
                channel.setSound(
                        android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                        new android.media.AudioAttributes.Builder()
                                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                                .build()
                );
                nm.createNotificationChannel(channel);
            }
        }
    }
}
