ADJ SERVICES — FCM DIAGNOSTIC BUILD 15.8.2-DIAG

Purpose:
This is a one-off diagnostic APK based on ADJ SERVICES V15.8.1.
It does NOT change the production app architecture. It adds a visible "FCM DIAG" button so the exact failure point can be seen without Logcat.

Test steps:
1. Install the diagnostic APK over the existing ADJ SERVICES APK.
2. Open the app and log in as a customer.
3. Wait 10-20 seconds.
4. Tap "FCM DIAG".
5. Tap "RUN TEST".
6. The panel records:
   - Firebase FCM token generation result (masked)
   - Supabase JS availability
   - authenticated session/user presence
   - ADJNative bridge availability
   - session handoff result
   - Supabase fcm_tokens HTTP status and response
7. Send a screenshot of the diagnostic panel.

Important:
- Do not send or publish the full FCM token or access/refresh token. The diagnostic UI masks the FCM token and never displays Supabase access/refresh tokens.
- This build is diagnostic only. Do not publish it as the production Play Store release.
- No Supabase database data is deleted or changed by the diagnostic UI.
