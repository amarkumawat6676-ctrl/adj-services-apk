# ADJ SERVICES V15.3 — GitHub Ready

This repository is the Android project root for the ADJ SERVICES V15.3 release build.

## GitHub build

The workflow is `.github/workflows/build-apk.yml`.

It deliberately does **not** run the old `android-actions/setup-android@v3` / `sdkmanager` setup that caused the previous failure. GitHub's `ubuntu-24.04` runner already provides Android 35 and Build Tools 35.0.0; the workflow only verifies those installed components and then runs Gradle 8.7.

Build output:
`app/build/outputs/apk/release/app-release.apk`

GitHub Actions artifact:
`ADJ-SERVICES-V15.3-release`

Firebase `google-services.json` is already included at `app/google-services.json` and matches package `in.adjservices.app`.
