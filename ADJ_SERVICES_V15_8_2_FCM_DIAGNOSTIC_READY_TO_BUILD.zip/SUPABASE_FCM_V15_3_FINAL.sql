-- ADJ SERVICES V15.3 — FCM token registration and RLS
-- Run once in Supabase SQL Editor.
begin;

alter table public.fcm_tokens add column if not exists user_id uuid;
alter table public.fcm_tokens add column if not exists device_model text;
alter table public.fcm_tokens add column if not exists platform text default 'android';
alter table public.fcm_tokens add column if not exists created_at timestamptz not null default now();
alter table public.fcm_tokens add column if not exists updated_at timestamptz not null default now();

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'fcm_tokens_user_id_fkey'
      and conrelid = 'public.fcm_tokens'::regclass
  ) then
    alter table public.fcm_tokens
      add constraint fcm_tokens_user_id_fkey
      foreign key (user_id) references auth.users(id) on delete cascade;
  end if;
end $$;

create index if not exists fcm_tokens_user_id_idx on public.fcm_tokens(user_id);
create unique index if not exists fcm_tokens_token_uidx on public.fcm_tokens(token);

alter table public.fcm_tokens enable row level security;

grant usage on schema public to authenticated, service_role;
grant select, insert, update, delete on public.fcm_tokens to authenticated, service_role;

drop policy if exists fcm_tokens_select_own on public.fcm_tokens;
drop policy if exists fcm_tokens_insert_own on public.fcm_tokens;
drop policy if exists fcm_tokens_update_own on public.fcm_tokens;
drop policy if exists fcm_tokens_delete_own on public.fcm_tokens;

create policy fcm_tokens_select_own
on public.fcm_tokens for select to authenticated
using (auth.uid() = user_id);

create policy fcm_tokens_insert_own
on public.fcm_tokens for insert to authenticated
with check (auth.uid() = user_id);

create policy fcm_tokens_update_own
on public.fcm_tokens for update to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy fcm_tokens_delete_own
on public.fcm_tokens for delete to authenticated
using (auth.uid() = user_id);

commit;
