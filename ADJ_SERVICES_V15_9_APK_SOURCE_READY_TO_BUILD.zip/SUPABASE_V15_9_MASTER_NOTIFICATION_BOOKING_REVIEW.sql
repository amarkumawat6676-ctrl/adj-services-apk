-- ADJ SERVICES V15.9 MASTER WORKFLOW MIGRATION
-- Additive/safe. Run once in Supabase SQL Editor.
-- Covers: FCM service-role access, review approval, booking timestamps,
-- chat presence-aware notifications, technician/admin/customer notification routing.

begin;

-- 1) FCM server-side read access used by send-push Edge Function.
grant usage on schema public to service_role;
grant select on table public.fcm_tokens to service_role;

-- 2) Review moderation: new reviews start hidden until Admin publishes them.
alter table public.reviews add column if not exists is_visible boolean;
alter table public.reviews alter column is_visible set default false;
update public.reviews set is_visible=false where is_visible is null;

-- 3) Notification routing metadata.
alter table public.notifications add column if not exists metadata jsonb not null default '{}'::jsonb;
grant select, insert, update on public.notifications to authenticated;

-- 4) Security-definer notification helper for chat and role-targeted alerts.
create or replace function public.adj_create_user_notification(
  p_recipient_id uuid,
  p_title text,
  p_message text,
  p_type text default 'general',
  p_booking_id uuid default null,
  p_metadata jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare me uuid:=auth.uid(); rid uuid;
begin
  if me is null then raise exception 'Login required'; end if;
  if p_recipient_id is null then raise exception 'Recipient required'; end if;
  select id into rid from public.profiles where id=me and lower(coalesce(role,''))='admin';
  if rid is null and me<>p_recipient_id then
    raise exception 'Only Admin may notify another user';
  end if;
  insert into public.notifications(user_id,booking_id,title,message,type,is_read,metadata)
  values(p_recipient_id,p_booking_id,coalesce(nullif(trim(p_title),''),'ADJ SERVICES'),coalesce(nullif(trim(p_message),''),'You have a new update from ADJ SERVICES.'),coalesce(nullif(trim(p_type),''),'general'),false,coalesce(p_metadata,'{}'::jsonb));
  return jsonb_build_object('success',true);
end $$;
revoke all on function public.adj_create_user_notification(uuid,text,text,text,uuid,jsonb) from public;
grant execute on function public.adj_create_user_notification(uuid,text,text,text,uuid,jsonb) to authenticated;

create or replace function public.adj_create_chat_notification(
  p_recipient_id uuid,
  p_title text,
  p_message text,
  p_metadata jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare me uuid:=auth.uid(); sender_role text;
begin
  if me is null then raise exception 'Login required'; end if;
  if p_recipient_id is null or p_recipient_id=me then return jsonb_build_object('success',false,'skipped',true); end if;
  select lower(coalesce(role,'')) into sender_role from public.profiles where id=me;
  if sender_role not in ('customer','technician','admin') then raise exception 'Invalid sender role'; end if;
  insert into public.notifications(user_id,title,message,type,is_read,metadata)
  values(p_recipient_id,coalesce(nullif(trim(p_title),''),'New Message'),coalesce(nullif(trim(p_message),''),'You have a new message.'),'chat',false,coalesce(p_metadata,'{}'::jsonb));
  return jsonb_build_object('success',true);
end $$;
revoke all on function public.adj_create_chat_notification(uuid,text,text,jsonb) from public;
grant execute on function public.adj_create_chat_notification(uuid,text,text,jsonb) to authenticated;


-- 5) Server-side guard for Today: a slot whose start time has already passed cannot be booked.
-- Uses India time so the rule is not dependent on the database server's UTC timezone.
create or replace function public.customer_create_booking_v168(
  p_booking_code text,
  p_service_name text,
  p_customer_name text,
  p_customer_phone text,
  p_address text,
  p_appliance text,
  p_problem text,
  p_preferred_date date,
  p_preferred_time time,
  p_estimated_price numeric default 0,
  p_latitude double precision default null,
  p_longitude double precision default null,
  p_location_accuracy double precision default null
)
returns public.bookings
language plpgsql
security definer
set search_path=public
as $$
declare v_row public.bookings; v_now timestamp;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  v_now := now() at time zone 'Asia/Kolkata';
  if p_preferred_date = v_now::date and p_preferred_time <= v_now::time then
    raise exception 'Selected service time slot has already passed. Please choose a later slot.';
  end if;
  insert into public.bookings(
    booking_code,customer_id,service_name,customer_name,customer_phone,address,
    appliance,problem,preferred_date,preferred_time,status,estimated_price,
    latitude,longitude,location_accuracy
  ) values (
    p_booking_code,auth.uid(),coalesce(nullif(trim(p_service_name),''),'Service'),
    coalesce(nullif(trim(p_customer_name),''),'Customer'),coalesce(p_customer_phone,''),
    coalesce(nullif(trim(p_address),''),'Jaipur'),coalesce(nullif(trim(p_appliance),''),'General'),
    coalesce(nullif(trim(p_problem),''),'Not specified'),p_preferred_date,p_preferred_time,
    'Pending',coalesce(p_estimated_price,0),p_latitude,p_longitude,p_location_accuracy
  ) returning * into v_row;
  return v_row;
end;
$$;
grant execute on function public.customer_create_booking_v168(text,text,text,text,text,text,text,date,time,numeric,double precision,double precision,double precision) to authenticated;

commit;
