const CACHE='adj-services-v19-2-29-v15-2';
const APP_SHELL=['./','./index.html','./customer.html','./admin.html','./technician.html','./manifest.json','./app-version.json'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(APP_SHELL)).catch(()=>{}).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;
  const u=new URL(r.url);if(u.origin!==self.location.origin)return;
  e.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    // HTML/portal pages must always prefer the network so an older cached
    // design can never flash when Admin or Technician is opened.
    if(r.mode==='navigate' || r.destination==='document' || /\\.(html?)$/i.test(u.pathname)){
      try{const res=await fetch(r,{cache:'no-store'});if(res&&res.ok)cache.put(r,res.clone());return res;}
      catch(_){const cached=await cache.match(r);return cached||new Response('Offline — please reconnect.',{status:503,headers:{'Content-Type':'text/plain'}})}
    }
    const cached=await cache.match(r);
    if(cached){fetch(r,{cache:'no-store'}).then(res=>{if(res&&res.ok)cache.put(r,res.clone())}).catch(()=>{});return cached;}
    try{const res=await fetch(r,{cache:'no-store'});if(res&&res.ok)cache.put(r,res.clone());return res}
    catch(_){return new Response('Offline — please reconnect.',{status:503,headers:{'Content-Type':'text/plain'}})}
  })());
});
self.addEventListener('push',e=>{let data={title:'ADJ SERVICES',body:'You have a new update.',url:'/'};try{if(e.data)data={...data,...e.data.json()}}catch(_){try{if(e.data)data.body=e.data.text()}catch(__){}}e.waitUntil(self.registration.showNotification(data.title,{body:data.body,icon:'/icons/icon-192.png',badge:'/icons/icon-64.png',data:{url:data.url||'/'},tag:data.tag||'adj-services',vibrate:[200,100,200],renotify:true}))});
self.addEventListener('notificationclick',e=>{e.notification.close();const url=e.notification.data?.url||'/';e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{for(const c of cs){if('focus'in c){c.navigate(url);return c.focus()}}return clients.openWindow(url)}))});
