ADJ SERVICES V15.9.7 FINAL TEST BUILD

Fixes:
- Pre-boot loader appears before Welcome for first-time users.
- Existing authenticated session bypasses Welcome: loader -> Customer Dashboard.
- Loader logo is geometrically centered; no nested core layout.
- Real appliance SVG icons remain in the rotating 3D orbit.
- Customer/Admin/Technician Close App dialog uses native closeApp() in the APK.
- Customer session is not logged out by Android Back; only Profile Logout signs out.
- Customer Reviews auto-slide RTL and Gallery auto-slide LTR are preserved in hosted customer.html.

The hosted customer/admin/technician pages remain live from Cloudflare Pages; this APK source adds the native closeApp bridge and bundles the corrected index preboot loader.
