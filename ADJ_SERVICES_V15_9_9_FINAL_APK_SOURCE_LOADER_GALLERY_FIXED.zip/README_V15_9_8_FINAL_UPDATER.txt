ADJ SERVICES V15.9.8 FINAL

Changes:
- Removed visible FCM Diagnostic button/dialog from the production APK source.
- Preserved native FCM registration and notification functionality.
- Version bumped to 15.9.8 / versionCode 35.
- Native updater now reads the single production manifest at:
  https://adjservices.pages.dev/app-version.json
- The manifest is cache-busted on every check and compares latestVersionCode against the installed APK.
- Profile > Check Latest Version reads the same manifest and, inside the APK, can start the native APK download.
- Stable APK download URL remains the GitHub latest-release asset URL.
- The website manifest must be updated for every future APK release.
