ADJ SERVICES V14.6 - READY TO BUILD

1. Create/open your GitHub repository.
2. Upload the contents of this ZIP to the repository root.
3. Keep the Android source ZIP in the repository root.
4. The included .github/workflows/build-apk.yml automatically finds the source ZIP,
   extracts it, installs JDK 17 + Android SDK + Gradle 8.10.2, and builds a signed
   Release APK.
5. In GitHub open Actions -> Build ADJ SERVICES APK -> Run workflow.
6. When the workflow finishes, download the artifact named ADJ-SERVICES-APK.

IMPORTANT:
- This workflow expects the release keystore/password currently packaged with the
  project. Do not publish the keystore or password in a public repository.
- The APK updater in V14.6 checks the configured app-version.json URL and downloads
  the configured update APK URL. For production, the release APK must remain at a
  stable HTTPS URL and app-version.json must point to the latest release.
